import React, { useState, useMemo } from 'react';
import {
  Zap,
  TowerControl as Tower,
  Activity,
  AlertTriangle,
  Flame,
  Scissors,
  Wrench,
  ShieldCheck,
  Camera,
  Filter,
  CheckCircle,
  Clock,
  PlayCircle,
  ArrowRight,
  TrendingUp,
  BarChart3,
  PieChart
} from 'lucide-react';
import {
  LineaSubtransmision,
  Estructura,
  EfectoCorona,
  Deficiencia,
  Termografia,
  Poda,
  Mantenimiento,
  DMSItem,
  ConfiguracionDrive
} from '../types';

interface DashboardViewProps {
  lineas: LineaSubtransmision[];
  estructuras: Estructura[];
  corona: EfectoCorona[];
  deficiencias: Deficiencia[];
  termografia: Termografia[];
  podas: Poda[];
  mantenimiento: Mantenimiento[];
  dms: DMSItem[];
  configDrive: ConfiguracionDrive;
  selectedLine: string;
  onSelectLine: (line: string) => void;
  onNavigateTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  lineas,
  estructuras,
  corona,
  deficiencias,
  termografia,
  podas,
  mantenimiento,
  dms,
  configDrive,
  selectedLine,
  onSelectLine,
  onNavigateTab
}) => {
  const [filterPrioridad, setFilterPrioridad] = useState<string>('TODAS');

  // Filter datasets by selected line
  const filteredEstructuras = useMemo(() => {
    return selectedLine === 'TODAS' ? estructuras : estructuras.filter(e => e.cod_linea === selectedLine);
  }, [estructuras, selectedLine]);

  const filteredCorona = useMemo(() => {
    return selectedLine === 'TODAS' ? corona : corona.filter(c => c.cod_linea === selectedLine);
  }, [corona, selectedLine]);

  const filteredDeficiencias = useMemo(() => {
    let list = selectedLine === 'TODAS' ? deficiencias : deficiencias.filter(d => d.cod_linea === selectedLine);
    if (filterPrioridad !== 'TODAS') {
      list = list.filter(d => d.prioridad === filterPrioridad);
    }
    return list;
  }, [deficiencias, selectedLine, filterPrioridad]);

  const filteredTermografia = useMemo(() => {
    return selectedLine === 'TODAS' ? termografia : termografia.filter(t => t.cod_linea === selectedLine);
  }, [termografia, selectedLine]);

  const filteredPodas = useMemo(() => {
    return selectedLine === 'TODAS' ? podas : podas.filter(p => p.cod_linea === selectedLine);
  }, [podas, selectedLine]);

  const filteredMantenimiento = useMemo(() => {
    return selectedLine === 'TODAS' ? mantenimiento : mantenimiento.filter(m => m.cod_linea === selectedLine);
  }, [mantenimiento, selectedLine]);

  const filteredDMS = useMemo(() => {
    return selectedLine === 'TODAS' ? dms : dms.filter(d => d.cod_linea === selectedLine);
  }, [dms, selectedLine]);

  // Key metrics
  const totalLineas = lineas.length;
  const totalEstructuras = filteredEstructuras.length;
  const totalCorona = filteredCorona.length;
  const coronaAlertas = filteredCorona.filter(c => c.prioridad === 'PRIORITARIO' || c.fase_r_conteo > 100 || c.fase_s_conteo > 100 || c.fase_t_conteo > 100).length;

  const totalDeficiencias = filteredDeficiencias.length;
  const defPrioritarias = filteredDeficiencias.filter(d => d.prioridad === 'PRIORITARIO').length;
  const defPendientes = filteredDeficiencias.filter(d => d.estado !== 'Cerrada' && d.estado !== 'Corregida').length;
  const defCorregidas = filteredDeficiencias.filter(d => d.estado === 'Corregida' || d.estado === 'Cerrada').length;

  const totalTermografias = filteredTermografia.length;
  const termCriticas = filteredTermografia.filter(t => t.criticidad === 'Alerta' || t.criticidad === 'Emergencia').length;

  const totalPodas = filteredPodas.length;
  const totalArboles = filteredPodas.reduce((acc, p) => acc + (p.total_arboles || 0), 0);

  const totalDMS = filteredDMS.length;
  const dmsPendientes = filteredDMS.filter(d => d.estado === 'Pendiente' || d.estado === 'Asignada').length;
  const dmsLevantadas = filteredDMS.filter(d => d.estado === 'Levantada').length;
  const dmsCerradas = filteredDMS.filter(d => d.estado === 'Cerrada').length;

  // Maintenance Status Metrics
  const totalMantenimientos = filteredMantenimiento.length;
  const mantProgramado = filteredMantenimiento.filter(m => m.estado === 'Programado').length;
  const mantEnProceso = filteredMantenimiento.filter(m => m.estado === 'En Proceso').length;
  const mantFinalizado = filteredMantenimiento.filter(m => m.estado === 'Finalizado').length;
  const mantAprobado = filteredMantenimiento.filter(m => m.estado === 'Aprobado').length;

  // Donut slices for Maintenance
  const mantSlices = [
    { label: 'Aprobado', count: mantAprobado, color: '#10B981', textColor: 'text-emerald-400', bg: 'bg-emerald-500' },
    { label: 'Finalizado', count: mantFinalizado, color: '#3B82F6', textColor: 'text-blue-400', bg: 'bg-blue-500' },
    { label: 'En Proceso', count: mantEnProceso, color: '#F59E0B', textColor: 'text-amber-400', bg: 'bg-amber-500' },
    { label: 'Programado', count: mantProgramado, color: '#06B6D4', textColor: 'text-cyan-400', bg: 'bg-cyan-500' }
  ];

  // SVG Donut calculation helper
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  let accumulatedPercent = 0;

  // Top 10 Corona measurements for SVG Bar chart
  const topCorona = useMemo(() => {
    return [...filteredCorona]
      .sort((a, b) => Math.max(b.fase_r_conteo, b.fase_s_conteo, b.fase_t_conteo) - Math.max(a.fase_r_conteo, a.fase_s_conteo, a.fase_t_conteo))
      .slice(0, 8);
  }, [filteredCorona]);

  const maxCoronaPhotons = useMemo(() => {
    let max = 150;
    topCorona.forEach(c => {
      max = Math.max(max, c.fase_r_conteo, c.fase_s_conteo, c.fase_t_conteo);
    });
    return max;
  }, [topCorona]);

  // Tree species totals for Podas chart
  const speciesData = useMemo(() => {
    const s = {
      Algarrobo: 0,
      Palmera: 0,
      Ornamental: 0,
      Tamarindo: 0,
      Ponceana: 0,
      Otros: 0
    };
    filteredPodas.forEach(p => {
      s.Algarrobo += p.algarrobo || 0;
      s.Palmera += p.palmera || 0;
      s.Ornamental += p.ornamental || 0;
      s.Tamarindo += p.tamarindo || 0;
      s.Ponceana += p.ponceana || 0;
      s.Otros += p.otros || 0;
    });
    return Object.entries(s);
  }, [filteredPodas]);

  const maxSpeciesCount = Math.max(1, ...speciesData.map(([, v]) => v));

  return (
    <div className="space-y-6">
      {/* Top Filter and Status Header */}
      <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-cyan-400" />
            <h1 className="text-xl font-bold text-white tracking-tight">Dashboard General de Subtransmisión</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Supervisión consolidada en tiempo real de 27 líneas de 60 kV y 33 kV.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-300">Filtrar por Línea:</span>
            <select
              value={selectedLine}
              onChange={(e) => onSelectLine(e.target.value)}
              className="bg-slate-900 text-xs font-bold text-cyan-300 border border-slate-700 rounded-xl px-3 py-2 focus:ring-2 focus:ring-cyan-500 cursor-pointer"
            >
              <option value="TODAS">Todas las Líneas ({lineas.length})</option>
              {lineas.map((l) => (
                <option key={l.id_linea} value={l.cod_linea}>
                  {l.cod_linea} - {l.nombre}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Líneas */}
        <div
          onClick={() => onNavigateTab('lineas')}
          className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 rounded-2xl p-4 shadow-md cursor-pointer transition transform hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider">Líneas ST</span>
            <div className="p-1.5 rounded-lg bg-cyan-950 text-cyan-400">
              <Zap className="h-4 w-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{totalLineas}</div>
          <div className="text-[10px] text-cyan-400 font-medium mt-1">60 kV y 33 kV Operativas</div>
        </div>

        {/* Estructuras */}
        <div
          onClick={() => onNavigateTab('estructuras')}
          className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 rounded-2xl p-4 shadow-md cursor-pointer transition transform hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider">Estructuras</span>
            <div className="p-1.5 rounded-lg bg-blue-950 text-blue-400">
              <Tower className="h-4 w-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{totalEstructuras.toLocaleString()}</div>
          <div className="text-[10px] text-blue-400 font-medium mt-1">Madera, CAC y Celosía</div>
        </div>

        {/* Efecto Corona */}
        <div
          onClick={() => onNavigateTab('corona')}
          className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 rounded-2xl p-4 shadow-md cursor-pointer transition transform hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider">Efecto Corona</span>
            <div className="p-1.5 rounded-lg bg-purple-950 text-purple-400">
              <Activity className="h-4 w-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{totalCorona}</div>
          <div className="text-[10px] text-purple-400 font-medium mt-1">
            {coronaAlertas > 0 ? (
              <span className="text-amber-400 font-bold">{coronaAlertas} con descargas &gt;100 fot/m</span>
            ) : (
              'Mediciones UV en rango'
            )}
          </div>
        </div>

        {/* Deficiencias */}
        <div
          onClick={() => onNavigateTab('deficiencias')}
          className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 rounded-2xl p-4 shadow-md cursor-pointer transition transform hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider">Deficiencias</span>
            <div className="p-1.5 rounded-lg bg-red-950 text-red-400">
              <AlertTriangle className="h-4 w-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{totalDeficiencias}</div>
          <div className="text-[10px] text-red-400 font-medium mt-1">
            {defPrioritarias} Prioritarias • {defPendientes} Pendientes
          </div>
        </div>

        {/* Mantenimientos */}
        <div
          onClick={() => onNavigateTab('mantenimiento')}
          className="bg-slate-800/80 hover:bg-slate-800 border border-cyan-500/40 rounded-2xl p-4 shadow-md cursor-pointer transition transform hover:-translate-y-0.5 ring-1 ring-cyan-500/20"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-300">Mantenimiento</span>
            <div className="p-1.5 rounded-lg bg-cyan-950 text-cyan-400">
              <Wrench className="h-4 w-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-cyan-300">{totalMantenimientos}</div>
          <div className="text-[10px] text-cyan-400 font-medium mt-1">
            {mantAprobado + mantFinalizado} Realizados • {mantProgramado + mantEnProceso} Activos
          </div>
        </div>

        {/* DMS */}
        <div
          onClick={() => onNavigateTab('dms')}
          className="bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 rounded-2xl p-4 shadow-md cursor-pointer transition transform hover:-translate-y-0.5"
        >
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider">Casos DMS</span>
            <div className="p-1.5 rounded-lg bg-amber-950 text-amber-400">
              <ShieldCheck className="h-4 w-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-white">{totalDMS}</div>
          <div className="text-[10px] text-amber-400 font-medium mt-1">
            {dmsLevantadas} Levantadas • {dmsCerradas} Cerradas
          </div>
        </div>
      </div>

      {/* CORE USER REQUEST: MAINTENANCE STATUS CHART (GRÁFICO ESTADO DE MANTENIMIENTOS) */}
      <div className="bg-slate-800/90 border border-cyan-500/40 rounded-2xl p-5 shadow-xl ring-1 ring-cyan-500/10">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-700/70 mb-5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 text-white shadow-md shadow-cyan-600/30">
              <Wrench className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight">
                  Estado de los Mantenimientos de Líneas
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-700 font-semibold">
                  {totalMantenimientos} Órdenes
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Distribución del ciclo de vida de mantenimiento: Programado, En Proceso, Finalizado y Aprobado
              </p>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('mantenimiento')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md shadow-cyan-600/30 transition self-start sm:self-auto cursor-pointer"
          >
            <span>Ver Órdenes de Mantenimiento</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* SVG Donut Chart for Maintenance */}
          <div className="lg:col-span-5 flex flex-col sm:flex-row items-center justify-center gap-6 p-2">
            <div className="relative w-44 h-44 flex items-center justify-center flex-shrink-0">
              <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 160 160">
                <circle
                  cx="80"
                  cy="80"
                  r={radius}
                  className="text-slate-800"
                  strokeWidth="18"
                  stroke="currentColor"
                  fill="transparent"
                />
                {totalMantenimientos > 0 &&
                  mantSlices.map((slice, index) => {
                    const percent = (slice.count / totalMantenimientos) * 100;
                    const strokeDasharray = `${(percent * circumference) / 100} ${circumference}`;
                    const strokeDashoffset = -((accumulatedPercent * circumference) / 100);
                    accumulatedPercent += percent;

                    if (slice.count === 0) return null;

                    return (
                      <circle
                        key={index}
                        cx="80"
                        cy="80"
                        r={radius}
                        stroke={slice.color}
                        strokeWidth="18"
                        strokeDasharray={strokeDasharray}
                        strokeDashoffset={strokeDashoffset}
                        strokeLinecap="round"
                        fill="transparent"
                        className="transition-all duration-500"
                      />
                    );
                  })}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-2xl font-black text-white">{totalMantenimientos}</span>
                <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">Órdenes</span>
              </div>
            </div>

            {/* Legend / Status Badges */}
            <div className="space-y-2.5 w-full sm:w-auto">
              {mantSlices.map((slice) => {
                const pct = totalMantenimientos > 0 ? Math.round((slice.count / totalMantenimientos) * 100) : 0;
                return (
                  <div key={slice.label} className="flex items-center justify-between gap-4 text-xs">
                    <div className="flex items-center gap-2">
                      <span className={`w-3 h-3 rounded-full ${slice.bg}`} />
                      <span className="text-slate-300 font-medium">{slice.label}</span>
                    </div>
                    <div className="flex items-center gap-1.5 font-mono">
                      <span className={`font-bold ${slice.textColor}`}>{slice.count}</span>
                      <span className="text-[11px] text-slate-500">({pct}%)</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Maintenance Progress & Types Overview */}
          <div className="lg:col-span-7 bg-slate-900/80 rounded-2xl p-4 border border-slate-700/70 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <TrendingUp className="h-4 w-4 text-cyan-400" />
                Avance General de Órdenes de Mantenimiento
              </span>
              <span className="text-xs font-mono font-bold text-emerald-400">
                {totalMantenimientos > 0 ? Math.round(((mantFinalizado + mantAprobado) / totalMantenimientos) * 100) : 0}% Ejecutado
              </span>
            </div>

            {/* Multi-segment progress bar */}
            <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden flex shadow-inner">
              {totalMantenimientos > 0 && (
                <>
                  <div style={{ width: `${(mantAprobado / totalMantenimientos) * 100}%` }} className="bg-emerald-500" title={`Aprobado: ${mantAprobado}`} />
                  <div style={{ width: `${(mantFinalizado / totalMantenimientos) * 100}%` }} className="bg-blue-500" title={`Finalizado: ${mantFinalizado}`} />
                  <div style={{ width: `${(mantEnProceso / totalMantenimientos) * 100}%` }} className="bg-amber-500" title={`En Proceso: ${mantEnProceso}`} />
                  <div style={{ width: `${(mantProgramado / totalMantenimientos) * 100}%` }} className="bg-cyan-500" title={`Programado: ${mantProgramado}`} />
                </>
              )}
            </div>

            {/* Maintenance by Type Breakdown */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1 text-center">
              <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Preventivo</div>
                <div className="text-base font-extrabold text-white mt-0.5">
                  {filteredMantenimiento.filter(m => m.tipo_mantenimiento === 'Preventivo').length}
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Correctivo</div>
                <div className="text-base font-extrabold text-white mt-0.5">
                  {filteredMantenimiento.filter(m => m.tipo_mantenimiento === 'Correctivo').length}
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Predictivo</div>
                <div className="text-base font-extrabold text-white mt-0.5">
                  {filteredMantenimiento.filter(m => m.tipo_mantenimiento === 'Predictivo').length}
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                <div className="text-[10px] text-slate-400 font-bold uppercase">Emergencia</div>
                <div className="text-base font-extrabold text-white mt-0.5">
                  {filteredMantenimiento.filter(m => m.tipo_mantenimiento === 'Emergencia').length}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Row 2: Charts for Corona UV & Deficiencias */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: Corona Multi-Phase Top Photons */}
        <div className="lg:col-span-2 bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Activity className="h-4 w-4 text-purple-400" />
                  Mediciones de Efecto Corona UV (Top Fotones por Fase)
                </h2>
                <p className="text-xs text-slate-400">
                  Estructuras con mayor nivel de conteo fotónico registradas (Cámara UV DayCor)
                </p>
              </div>
              <button
                onClick={() => onNavigateTab('corona')}
                className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 underline cursor-pointer"
              >
                Ver todas &rarr;
              </button>
            </div>

            {/* SVG Bar Chart for Corona */}
            <div className="mt-4 space-y-3">
              {topCorona.length === 0 ? (
                <div className="py-12 text-center text-xs text-slate-500">
                  No hay mediciones registradas para los filtros activos.
                </div>
              ) : (
                topCorona.map((c) => {
                  const maxVal = Math.max(c.fase_r_conteo, c.fase_s_conteo, c.fase_t_conteo);
                  const isAlert = maxVal > 100 || c.prioridad === 'PRIORITARIO';
                  return (
                    <div key={c.id_corona} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-mono font-bold text-white">
                          {c.cod_linea} P-{c.poste_n}
                          {isAlert && <span className="ml-2 text-[10px] text-amber-400 font-sans font-bold">⚠️ ALERTA</span>}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          R: <strong className="text-red-400">{c.fase_r_conteo}</strong> • S: <strong className="text-blue-400">{c.fase_s_conteo}</strong> • T: <strong className="text-emerald-400">{c.fase_t_conteo}</strong> fot/min
                        </span>
                      </div>
                      <div className="h-2.5 w-full bg-slate-900 rounded-full overflow-hidden flex gap-0.5">
                        <div style={{ width: `${(c.fase_r_conteo / maxCoronaPhotons) * 100}%` }} className="bg-red-500 rounded-full transition-all" />
                        <div style={{ width: `${(c.fase_s_conteo / maxCoronaPhotons) * 100}%` }} className="bg-blue-500 rounded-full transition-all" />
                        <div style={{ width: `${(c.fase_t_conteo / maxCoronaPhotons) * 100}%` }} className="bg-emerald-500 rounded-full transition-all" />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-500" /> Fase R</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-blue-500" /> Fase S</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Fase T</span>
            </div>
            <span>Límite de Alerta: &gt;100 fot/min</span>
          </div>
        </div>

        {/* Chart 2: Deficiencias por Prioridad */}
        <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-red-400" />
                Deficiencias por Prioridad
              </h2>
              <button
                onClick={() => onNavigateTab('deficiencias')}
                className="text-xs text-cyan-400 hover:text-cyan-300 cursor-pointer"
              >
                Detalles &rarr;
              </button>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Distribución de criticidad según norma de supervisión
            </p>

            {/* Donut representation */}
            <div className="flex flex-col items-center justify-center py-4">
              <div className="relative w-36 h-36 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 160 160">
                  <circle cx="80" cy="80" r={radius} className="text-slate-800" strokeWidth="18" stroke="currentColor" fill="transparent" />
                  {totalDeficiencias > 0 && (
                    <>
                      <circle
                        cx="80"
                        cy="80"
                        r={radius}
                        stroke="#EF4444"
                        strokeWidth="18"
                        strokeDasharray={`${(defPrioritarias / totalDeficiencias) * circumference} ${circumference}`}
                        strokeLinecap="round"
                        fill="transparent"
                      />
                      <circle
                        cx="80"
                        cy="80"
                        r={radius}
                        stroke="#06B6D4"
                        strokeWidth="18"
                        strokeDasharray={`${((totalDeficiencias - defPrioritarias) / totalDeficiencias) * circumference} ${circumference}`}
                        strokeDashoffset={-((defPrioritarias / totalDeficiencias) * circumference)}
                        strokeLinecap="round"
                        fill="transparent"
                      />
                    </>
                  )}
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <span className="text-2xl font-black text-white">{totalDeficiencias}</span>
                  <span className="text-[10px] text-slate-400 uppercase">Deficiencias</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-700/60 space-y-2 text-xs">
            <div className="flex justify-between text-slate-300">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-red-500" /> Prioritarias:</span>
              <strong className="text-red-400 font-mono font-bold">{defPrioritarias}</strong>
            </div>
            <div className="flex justify-between text-slate-300">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-cyan-500" /> No Prioritarias:</span>
              <strong className="text-cyan-400 font-mono font-bold">{totalDeficiencias - defPrioritarias}</strong>
            </div>
            <div className="flex justify-between text-slate-400 pt-1 border-t border-slate-800">
              <span>Pendientes de atención:</span>
              <span className="text-amber-400 font-mono font-bold">{defPendientes}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3: Podas Species & DMS Life Cycle */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Podas by Species */}
        <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Scissors className="h-4 w-4 text-emerald-400" />
              Especies de Árboles Podados
            </h2>
            <button
              onClick={() => onNavigateTab('podas')}
              className="text-xs text-cyan-400 hover:text-cyan-300 cursor-pointer"
            >
              Registrar &rarr;
            </button>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Total de árboles despejados en franja de servidumbre: <strong className="text-emerald-300 font-bold">{totalArboles}</strong>
          </p>

          <div className="space-y-3">
            {speciesData.map(([specie, count]) => (
              <div key={specie} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300">{specie}</span>
                  <span className="font-mono font-bold text-emerald-400">{count}</span>
                </div>
                <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${(count / maxSpeciesCount) * 100}%` }}
                    className="h-full bg-emerald-500 rounded-full transition-all duration-300"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* DMS Life Cycle */}
        <div className="bg-slate-800/90 border border-slate-700/80 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-amber-400" />
                Gestión y Ciclo de Vida DMS
              </h2>
              <button
                onClick={() => onNavigateTab('dms')}
                className="text-xs text-cyan-400 hover:text-cyan-300 cursor-pointer"
              >
                Módulo DMS &rarr;
              </button>
            </div>
            <p className="text-xs text-slate-400 mb-4">
              Estado de Distancias Mínimas de Seguridad observadas
            </p>

            <div className="grid grid-cols-3 gap-3 text-center my-4">
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl">
                <div className="text-[10px] text-slate-400 uppercase font-bold">Pendientes</div>
                <div className="text-xl font-black text-amber-400 mt-1">{dmsPendientes}</div>
              </div>
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl">
                <div className="text-[10px] text-slate-400 uppercase font-bold">Levantadas</div>
                <div className="text-xl font-black text-blue-400 mt-1">{dmsLevantadas}</div>
              </div>
              <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl">
                <div className="text-[10px] text-slate-400 uppercase font-bold">Cerradas</div>
                <div className="text-xl font-black text-emerald-400 mt-1">{dmsCerradas}</div>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs text-slate-400">
            <span>Tasa de Levantamiento y Cierre:</span>
            <span className="font-mono font-bold text-emerald-400">
              {totalDMS > 0 ? Math.round(((dmsLevantadas + dmsCerradas) / totalDMS) * 100) : 0}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
