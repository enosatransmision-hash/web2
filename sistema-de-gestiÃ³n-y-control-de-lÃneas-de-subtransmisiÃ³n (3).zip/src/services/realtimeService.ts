import { Usuario } from '../types';

export interface ActiveUserPresence {
  id: string;
  user: Usuario;
  activeModule: string;
  activeLine: string;
  connectedAt: string;
}

export interface LiveNotification {
  id: string;
  title: string;
  message: string;
  user: string;
  timestamp: string;
}

type StateUpdateListener = (entity: string, action: string, data: any, fullState?: any) => void;
type PresenceListener = (users: ActiveUserPresence[]) => void;
type NotificationListener = (notification: LiveNotification) => void;
type ConnectionListener = (connected: boolean) => void;

class RealtimeService {
  private ws: WebSocket | null = null;
  private isConnected = false;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 2;
  private currentUser: Usuario | null = null;
  private currentModule = 'dashboard';
  private currentLine = 'TODAS';
  private clientId: string;

  private stateListeners: Set<StateUpdateListener> = new Set();
  private presenceListeners: Set<PresenceListener> = new Set();
  private notificationListeners: Set<NotificationListener> = new Set();
  private connectionListeners: Set<ConnectionListener> = new Set();

  private activeUsers: ActiveUserPresence[] = [];
  private heartbeatInterval: any = null;
  private pollingInterval: any = null;
  private lastKnownVersion = 0;
  private lastSeenAuditId = '';

  constructor() {
    // Generate or retrieve persistent tab client ID
    try {
      let storedId = sessionStorage.getItem('st_realtime_client_id');
      if (!storedId) {
        storedId = 'CLI-' + Math.random().toString(36).substring(2, 9);
        sessionStorage.setItem('st_realtime_client_id', storedId);
      }
      this.clientId = storedId;
    } catch {
      this.clientId = 'CLI-' + Math.random().toString(36).substring(2, 9);
    }
  }

  public connect(user?: Usuario) {
    if (user) {
      this.currentUser = user;
    }

    // Always start resilient HTTP polling fallback immediately
    this.startPollingFallback();

    // In browser environments with WebSocket support, attempt WebSocket connection
    if (typeof window !== 'undefined' && typeof WebSocket !== 'undefined') {
      if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
        return;
      }

      if (this.reconnectAttempts >= this.maxReconnectAttempts) {
        // Transparently rely on HTTP synchronization
        return;
      }

      try {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws`;

        this.ws = new WebSocket(wsUrl);

        this.ws.onopen = () => {
          this.isConnected = true;
          this.reconnectAttempts = 0;
          this.notifyConnection(true);

          if (this.currentUser) {
            this.identify(this.currentUser, this.currentModule, this.currentLine);
          }

          this.startHeartbeat();
        };

        this.ws.onmessage = (event) => {
          try {
            const msg = JSON.parse(event.data);
            this.handleServerMessage(msg);
          } catch {
            // ignore non-json
          }
        };

        this.ws.onclose = () => {
          this.stopHeartbeat();
          if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            setTimeout(() => this.connect(), 4000);
          }
        };

        this.ws.onerror = () => {
          // Handled gracefully without console error; HTTP polling is fully active
          this.ws = null;
        };
      } catch {
        // Handled gracefully
      }
    }
  }

  private startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeatInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN && this.currentUser) {
        this.ws.send(JSON.stringify({
          type: 'presence:heartbeat',
          activeModule: this.currentModule,
          activeLine: this.currentLine
        }));
      }
    }, 15000);
  }

  private stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  /**
   * Resilient Polling Fallback ensures multi-user sync and presence continue seamlessly
   * even behind reverse proxies or iframes where WebSocket upgrades are blocked.
   */
  private startPollingFallback() {
    if (this.pollingInterval) return;

    // Initial immediate poll
    this.pollServer();

    // Recurring poll every 3 seconds
    this.pollingInterval = setInterval(() => {
      this.pollServer();
    }, 3000);
  }

  private async pollServer() {
    try {
      const res = await fetch('/api/presence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientId: this.clientId,
          user: this.currentUser,
          activeModule: this.currentModule,
          activeLine: this.currentLine
        })
      });

      if (!res.ok) return;

      const data = await res.json();

      if (!this.isConnected) {
        this.isConnected = true;
        this.notifyConnection(true);
      }

      if (data.activeUsers && Array.isArray(data.activeUsers)) {
        this.activeUsers = data.activeUsers;
        this.notifyPresence(this.activeUsers);
      }

      // Check if server version has updated
      if (data.version && data.version > this.lastKnownVersion) {
        const isFirstRun = this.lastKnownVersion === 0;
        this.lastKnownVersion = data.version;

        if (!isFirstRun) {
          // Fetch updated state and notify listeners
          const stateRes = await fetch('/api/state');
          if (stateRes.ok) {
            const fullState = await stateRes.json();
            this.notifyState('all', 'init', fullState, fullState);

            // Notify if changes were made by another user
            if (data.lastAudit && data.lastAudit.id_auditoria !== this.lastSeenAuditId) {
              this.lastSeenAuditId = data.lastAudit.id_auditoria;
              const isDifferentUser = !this.currentUser || !data.lastAudit.usuario.includes(this.currentUser.nombres);
              if (isDifferentUser) {
                this.notifyNotification({
                  id: 'NOTIF-' + Date.now(),
                  title: `Actualización: ${data.lastAudit.modulo}`,
                  message: data.lastAudit.valores_nuevos || 'Datos actualizados en el sistema',
                  user: `${data.lastAudit.usuario} (${data.lastAudit.rol})`,
                  timestamp: data.lastAudit.hora || 'Ahora'
                });
              }
            }
          }
        }
      }
    } catch {
      // Offline or network transient error
    }
  }

  public identify(user: Usuario, activeModule?: string, activeLine?: string) {
    this.currentUser = user;
    if (activeModule) this.currentModule = activeModule;
    if (activeLine) this.currentLine = activeLine;

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'auth:identify',
        user: {
          id_usuario: user.id_usuario,
          nombres: user.nombres,
          apellidos: user.apellidos,
          username: user.username,
          rol: user.rol,
          email: user.email
        },
        activeModule: this.currentModule,
        activeLine: this.currentLine
      }));
    }

    // Trigger instant HTTP heartbeat
    this.pollServer();
  }

  public updatePresence(moduleName: string, lineCode: string) {
    this.currentModule = moduleName;
    this.currentLine = lineCode;

    if (this.ws && this.ws.readyState === WebSocket.OPEN && this.currentUser) {
      this.ws.send(JSON.stringify({
        type: 'presence:heartbeat',
        activeModule: moduleName,
        activeLine: lineCode
      }));
    }

    // Ping server with new module presence
    this.pollServer();
  }

  private handleServerMessage(msg: any) {
    switch (msg.type) {
      case 'init': {
        if (msg.activeUsers) {
          this.activeUsers = msg.activeUsers;
          this.notifyPresence(this.activeUsers);
        }
        if (msg.data && msg.data.version) {
          this.lastKnownVersion = msg.data.version;
        }
        this.notifyState('all', 'init', msg.data, msg.data);
        break;
      }

      case 'presence:update': {
        this.activeUsers = msg.activeUsers || [];
        this.notifyPresence(this.activeUsers);
        break;
      }

      case 'state:patch': {
        if (msg.version) {
          this.lastKnownVersion = msg.version;
        }
        this.notifyState(msg.entity, msg.action, msg.data);
        if (msg.notification) {
          this.notifyNotification({
            id: 'NOTIF-' + Date.now(),
            title: msg.notification.title,
            message: msg.notification.message,
            user: msg.notification.user,
            timestamp: msg.notification.timestamp
          });
        }
        break;
      }

      case 'sync:complete': {
        this.notifyNotification({
          id: 'NOTIF-SYNC-' + Date.now(),
          title: 'Sincronización de Google Drive Completada',
          message: `Datos actualizados a las ${msg.last_sync_time}`,
          user: 'Servidor Drive Sync',
          timestamp: msg.last_sync_time
        });
        break;
      }
    }
  }

  /**
   * Broadcast a mutation made by current user to server and all clients
   */
  public mutate(entity: string, action: string, data: any, shiftSubsequent?: boolean) {
    const payload = {
      type: 'mutate',
      entity,
      action,
      data,
      shiftSubsequent,
      user: this.currentUser
    };

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }

    // Always guarantee persistence via REST mutation
    fetch('/api/mutate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(() => {
        // Quick trigger poll to sync other components
        setTimeout(() => this.pollServer(), 200);
      })
      .catch(() => {
        // local storage backup handles client state
      });
  }

  // --- Listeners Subscriptions ---
  public onStateUpdate(fn: StateUpdateListener): () => void {
    this.stateListeners.add(fn);
    return () => this.stateListeners.delete(fn);
  }

  public onPresence(fn: PresenceListener): () => void {
    this.presenceListeners.add(fn);
    if (this.activeUsers.length > 0) fn(this.activeUsers);
    return () => this.presenceListeners.delete(fn);
  }

  public onNotification(fn: NotificationListener): () => void {
    this.notificationListeners.add(fn);
    return () => this.notificationListeners.delete(fn);
  }

  public onConnectionChange(fn: ConnectionListener): () => void {
    this.connectionListeners.add(fn);
    fn(this.isConnected);
    return () => this.connectionListeners.delete(fn);
  }

  private notifyState(entity: string, action: string, data: any, fullState?: any) {
    for (const fn of this.stateListeners) {
      fn(entity, action, data, fullState);
    }
  }

  private notifyPresence(users: ActiveUserPresence[]) {
    for (const fn of this.presenceListeners) {
      fn(users);
    }
  }

  private notifyNotification(notif: LiveNotification) {
    for (const fn of this.notificationListeners) {
      fn(notif);
    }
  }

  private notifyConnection(connected: boolean) {
    for (const fn of this.connectionListeners) {
      fn(connected);
    }
  }

  public getActiveUsers(): ActiveUserPresence[] {
    return this.activeUsers;
  }

  public getIsConnected(): boolean {
    return this.isConnected;
  }
}

export const realtimeService = new RealtimeService();
