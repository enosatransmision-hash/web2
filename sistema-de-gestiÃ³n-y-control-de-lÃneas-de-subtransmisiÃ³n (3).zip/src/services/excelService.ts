import * as XLSX from 'xlsx';
import {
  LineaSubtransmision,
  Estructura,
  EfectoCorona,
  Deficiencia,
  Poda,
  Mantenimiento,
  DMSItem,
  LevantamientoDMS,
  InspeccionCierreDMS,
  AuditoriaRegistro,
  Usuario,
  PuestaTierra,
  Termografia
} from '../types';

export class ExcelService {
  /**
   * Helper to download tabular data as Excel-compatible CSV with UTF-8 BOM
   */
  private static downloadExcelFile(data: Record<string, any>[], filename: string) {
    if (!data || data.length === 0) {
      console.warn('No hay datos para exportar a Excel');
      return;
    }

    const headers = Object.keys(data[0]);
    
    // Format rows with proper escaping for commas/semicolons and quotes
    const csvRows: string[] = [];
    csvRows.push(headers.join(';'));

    for (const row of data) {
      const values = headers.map(header => {
        let val = row[header];
        if (val === null || val === undefined) val = '';
        const stringVal = String(val).replace(/"/g, '""');
        if (stringVal.includes(';') || stringVal.includes('\n') || stringVal.includes('"')) {
          return `"${stringVal}"`;
        }
        return stringVal;
      });
      csvRows.push(values.join(';'));
    }

    // Add UTF-8 Byte Order Mark (BOM) so Excel reads accents (tildes, ñ) seamlessly
    const blob = new Blob(['\uFEFF' + csvRows.join('\r\n')], {
      type: 'text/csv;charset=utf-8;'
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename.endsWith('.csv') || filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  // 1. Export Líneas
  static exportLineas(lineas: LineaSubtransmision[], filename = 'Registro_Lineas.xlsx') {
    const data = lineas.map(l => ({
      ID_LINEA: l.id_linea,
      COD_LINEA: String(l.cod_linea),
      NOMBRE: l.nombre,
      TIPO_SISTEMA: l.tipo_sistema,
      TENSION_NOM: String(l.tension_nom),
      NODO_SALIDA: l.nodo_salida,
      NODO_LLEGADA: l.nodo_llegada,
      CELDA_SALIDA: l.celda_salida,
      CELDA_LLEGADA: l.celda_llegada,
      ESTADO: l.estado,
      ULTIMA_SINCRONIZACION: l.ultima_sincronizacion
    }));
    this.downloadExcelFile(data, filename);
  }

  // 2. Export Estructuras
  static exportEstructuras(estructuras: Estructura[], filename = 'Planilla_Estructuras.xlsx') {
    const data = estructuras.map(e => ({
      ID_POSTE: e.id_poste,
      COD_LINEA: String(e.cod_linea),
      POSTE_N: String(e.poste_n),
      TIPO_ARMADO: e.tipo_armado,
      POSTE_CANTIDAD: e.poste_cantidad,
      POSTE_MATERIAL: e.poste_material,
      CRUCETA_MATERIAL: e.cruceta_material,
      MENSULA_MATERIAL: e.mensula_material || '-',
      RIOSTRA_O_AMARRE_MATERIAL: e.riostra_o_amarre_material || '-',
      AISLADOR_MATERIAL: e.aislador_material,
      AISLADOR_CANT: e.aislador_cant,
      AISLADOR_TIPO: e.aislador_tipo || '-',
      CONDUCTOR_MATERIAL: e.conductor_material,
      CONDUCTOR_CALIBRE: e.conductor_calibre,
      CONDUCTOR_N_FASES: e.conductor_n_fases,
      ESTADO: e.estado,
      OBSERVACIONES: e.observaciones || '-'
    }));
    this.downloadExcelFile(data, filename);
  }

  // 3. Export Deficiencias
  static exportDeficiencias(deficiencias: Deficiencia[], filename = 'Inspeccion_Deficiencias.xlsx') {
    const data = deficiencias.map(d => ({
      ID_DEFICIENCIA: d.id_deficiencia,
      COD_LINEA: String(d.cod_linea),
      POSTE_N: String(d.poste_n),
      FECHA_INSPECCION: d.fecha_inspeccion,
      TIPO_DEFICIENCIA: d.tipo_deficiencia,
      DESCRIPCION: d.descripcion,
      PRIORIDAD: d.prioridad,
      NUMERO_OM: d.numero_om || '-',
      ESTADO: d.estado,
      USUARIO_RESPONSABLE: d.usuario_responsable,
      EVIDENCIA_URL: d.evidencia_fotografica,
      OBSERVACIONES: d.observaciones
    }));
    this.downloadExcelFile(data, filename);
  }

  // 4. Export Puesta a Tierra
  static exportPuestaTierra(patList: PuestaTierra[], filename = 'Mediciones_Puesta_a_Tierra.xlsx') {
    const data = patList.map(p => ({
      ID_PAT: p.id_pat,
      COD_LINEA: String(p.cod_linea),
      POSTE_N: String(p.poste_n),
      FECHA_MEDICION: p.fecha_medicion,
      VALOR_RESISTENCIA_OHMIOS: p.valor_resistencia_pat,
      PRIORIDAD: p.prioridad,
      ALERTA_DEFICIENCIA: p.alerta_deficiencia ? 'SI (≥ 5 Ω)' : 'NO (< 5 Ω)',
      TIPO_ESTRUCTURA: p.tipo_estructura || '-',
      MATERIAL_ESTRUCTURA: p.material_estructura || '-',
      UTM_ESTE: p.utm_este || '-',
      UTM_NORTE: p.utm_norte || '-',
      RESPONSABLE: p.responsable || '-',
      COMENTARIO: p.comentario || '-',
      EVIDENCIA_URL: p.evidencia_url || '-'
    }));
    this.downloadExcelFile(data, filename);
  }

  // 5. Export Efecto Corona
  static exportEfectoCorona(coronaList: EfectoCorona[], filename = 'Mediciones_Efecto_Corona_UV.xlsx') {
    const data = coronaList.map(c => ({
      ID_CORONA: c.id_corona,
      COD_LINEA: String(c.cod_linea),
      POSTE_N: String(c.poste_n),
      TIPO_ARMADO: c.tipo_armado,
      TIPO_AISLADOR: c.tipo_aislador,
      NIVEL_TENSION_KV: c.nivel_tension_kv,
      PRIORIDAD: c.prioridad || 'NO PRIORITARIO',
      DESCRIPCION_DETALLADA: c.descripcion_detallada || '-',
      CAUSA_PROBABLE: c.causa_probable || '-',
      ACCION_RECOMENDADA: c.accion_recomendada || '-',
      FECHA: c.fecha,
      HORA: c.hora,
      TEMP_C: c.temp_c,
      HUMEDAD_PCT: c.humedad_pct,
      FASE_R_GANANCIA: c.fase_r_ganancia,
      FASE_R_CONTEO: c.fase_r_conteo,
      FASE_S_GANANCIA: c.fase_s_ganancia,
      FASE_S_CONTEO: c.fase_s_conteo,
      FASE_T_GANANCIA: c.fase_t_ganancia,
      FASE_T_CONTEO: c.fase_t_conteo,
      SITUACIONES: (c.situaciones || []).join(', '),
      COMENTARIOS: c.comentarios,
      INSPECTOR: c.inspector,
      EVIDENCIA_URL: c.evidencia_url
    }));
    this.downloadExcelFile(data, filename);
  }

  // Alias for backward compatibility
  static exportCorona(coronaList: EfectoCorona[], filename = 'Mediciones_Efecto_Corona_UV.xlsx') {
    this.exportEfectoCorona(coronaList, filename);
  }

  // 6. Export Termografía
  static exportTermografia(termografiaList: Termografia[], filename = 'Inspecciones_Termograficas.xlsx') {
    const data = termografiaList.map(t => ({
      ID_TERMOGRAFIA: t.id_termografia,
      COD_LINEA: String(t.cod_linea),
      POSTE_N: String(t.poste_n),
      FECHA: t.fecha,
      HORA: t.hora,
      COMPONENTE_FALLA: t.componente_falla,
      TEMP_AMBIENTE_C: t.temp_ambiente,
      TEMP_MAX_COMPONENTE_C: t.temp_max_componente,
      DELTA_T_C: t.delta_t,
      CRITICIDAD: t.criticidad,
      EMISIVIDAD: t.emisividad,
      NIVEL_TENSION: t.nivel_tension,
      TIPO_ZONA: t.tipo_zona,
      COMENTARIO: t.comentario,
      INSPECTOR: t.inspector,
      EVIDENCIA_URL: t.evidencia_url
    }));
    this.downloadExcelFile(data, filename);
  }

  // 7. Export Podas
  static exportPodas(podasList: Poda[], filename = 'Control_Podas_Franja_Servidumbre.xlsx') {
    const data = podasList.map(p => ({
      ID_PODA: p.id_poda,
      COD_LINEA: String(p.cod_linea),
      POSTE_N: String(p.poste_n),
      FECHA_EJECUCION: p.fecha_ejecucion,
      ESTADO: p.estado,
      ALGARROBO: p.algarrobo,
      PALMERA: p.palmera,
      ORNAMENTAL: p.ornamental,
      TAMARINDO: p.tamarindo,
      PONCEANA: p.ponceana,
      OTROS: p.otros,
      TOTAL_ARBOLES: p.total_arboles,
      UBICACION_REFERENCIA: p.ubicacion_referencia,
      PUNTO_INICIAL: p.punto_inicial,
      PUNTO_FINAL: p.punto_final,
      CONTRATISTA_RESPONSABLE: p.contratista_responsable,
      OBSERVACIONES: p.observaciones
    }));
    this.downloadExcelFile(data, filename);
  }

  // 8. Export Mantenimiento
  static exportMantenimiento(mantList: Mantenimiento[], filename = 'Mantenimiento_Subtransmision.xlsx') {
    const data = mantList.map(m => ({
      ID_MANTENIMIENTO: m.id_mantenimiento,
      COD_LINEA: String(m.cod_linea),
      POSTE_N: String(m.poste_n),
      ORDEN_MANTENIMIENTO: m.orden_mantenimiento,
      FECHA_EJECUCION: m.fecha_ejecucion,
      TIPO_MANTENIMIENTO: m.tipo_mantenimiento,
      ACTIVIDAD_REALIZADA: m.actividad_realizada,
      ESTADO: m.estado,
      ALTERA_ESTRUCTURAS: m.altera_estructuras ? 'SI' : 'NO',
      CONTRATISTA_RESPONSABLE: m.contratista_responsable,
      OBSERVACIONES: m.observaciones
    }));
    this.downloadExcelFile(data, filename);
  }

  // 9. Export DMS
  static exportDMS(
    dmsList: DMSItem[],
    _levantamientos?: LevantamientoDMS[],
    _inspecciones?: InspeccionCierreDMS[],
    filename = 'Infracciones_DMS.xlsx'
  ) {
    const data = dmsList.map(d => ({
      ID_DMS: d.id_dms,
      CODIGO_DMS: d.codigo_dms,
      COD_LINEA: String(d.cod_linea),
      POSTE_N: String(d.poste_n),
      FECHA_IDENTIFICACION: d.fecha_identificacion,
      DESCRIPCION: d.descripcion,
      PRIORIDAD: d.prioridad,
      FUENTE: d.fuente,
      ORDEN_SERVICIO: d.orden_servicio,
      ESTADO: d.estado,
      OBSERVACIONES: d.observaciones
    }));
    this.downloadExcelFile(data, filename);
  }

  // 10. Export Usuarios
  static exportUsuarios(usuariosList: Usuario[], filename = 'USUARIOS.xlsx') {
    const data = usuariosList.map(u => ({
      ID_USUARIO: u.id_usuario,
      NOMBRES: u.nombres,
      APELLIDOS: u.apellidos,
      DNI: u.dni,
      EMAIL: u.email,
      TELEFONO: u.telefono,
      USERNAME: u.username,
      ROL: u.rol,
      ESTADO: u.estado,
      SUPERVISOR_RESPONSABLE: u.supervisor_responsable || '-',
      LINEAS_ASIGNADAS: u.lineas_asignadas.join(', '),
      FECHA_CREACION: u.fecha_creacion,
      ULTIMA_ACTUALIZACION: u.ultima_actualizacion || '-'
    }));
    this.downloadExcelFile(data, filename);
  }

  // 11. Export Auditoría
  static exportAuditoria(auditList: AuditoriaRegistro[], filename = 'Historial_Modificaciones.xlsx') {
    const data = auditList.map(a => ({
      ID_AUDITORIA: a.id_auditoria,
      FECHA: a.fecha,
      HORA: a.hora,
      USUARIO: a.usuario,
      ROL: a.rol,
      ACCION: a.accion,
      MODULO: a.modulo,
      ID_REGISTRO: a.id_registro,
      COD_LINEA: a.cod_linea,
      ESTRUCTURA: a.estructura,
      VALORES_NUEVOS: a.valores_nuevos,
      VALORES_ANTERIORES: a.valores_anteriores,
      ORIGEN: a.origen,
      RESULTADO: a.resultado,
      SYNC_ID: a.sync_id
    }));
    this.downloadExcelFile(data, filename);
  }

  // Read Excel/CSV file into sheet rows
  static async readExcelFile(file: File): Promise<{ sheetNames: string[]; data: Record<string, any[]> }> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const buffer = e.target?.result;
          const wb = XLSX.read(buffer, { type: 'binary' });
          const result: Record<string, any[]> = {};
          wb.SheetNames.forEach(sheetName => {
            const sheet = wb.Sheets[sheetName];
            result[sheetName] = XLSX.utils.sheet_to_json(sheet, { defval: '' });
          });
          resolve({ sheetNames: wb.SheetNames, data: result });
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = reject;
      reader.readAsBinaryString(file);
    });
  }
}
