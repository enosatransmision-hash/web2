export type RolUsuario = 'Administrador' | 'Supervisor' | 'Contratista';

export interface Usuario {
  id_usuario: string;
  nombres: string;
  apellidos: string;
  dni: string;
  email: string;
  telefono: string;
  username: string;
  rol: RolUsuario;
  estado: 'Activo' | 'Inactivo';
  supervisor_responsable?: string;
  lineas_asignadas: string[]; // List of COD_LINEA, or ['*'] for all
  fecha_creacion: string;
  password?: string;
  ultima_actualizacion?: string;
}

export interface LineaSubtransmision {
  id_linea: string;
  cod_linea: string;
  nombre: string;
  tipo_sistema: string;
  tension_nom: string;
  nodo_salida: string;
  nodo_llegada: string;
  celda_salida: string;
  celda_llegada: string;
  estado: 'Activo' | 'Inactivo' | 'En Mantenimiento';
  fecha_registro: string;
  ultima_sincronizacion: string;
}

export interface Estructura {
  id_poste: string;
  cod_linea: string;
  poste_n: string;
  tipo_armado: string;
  poste_cantidad: string;
  poste_material: string;
  cruceta_material: string;
  mensula_material: string;
  riostra_o_amarre_material: string;
  aislador_material: string;
  aislador_cant: string;
  aislador_tipo: string;
  conductor_material: string;
  conductor_calibre: string;
  conductor_n_fases: string;
  estado: 'Operativo' | 'En Mantenimiento' | 'Desactivado';
  observaciones?: string;
}

export type Prioridad = 'PRIORITARIO' | 'NO PRIORITARIO';

export interface PuestaTierra {
  id_pat: string;
  item?: number;
  cod_linea: string;
  poste_n: string;
  utm_este?: string;
  utm_norte?: string;
  tipo_estructura?: string;
  material_estructura?: string;
  fecha_medicion: string;
  valor_resistencia_pat: number;
  comentario?: string;
  prioridad: Prioridad;
  alerta_deficiencia?: boolean;
  id_deficiencia_relacionada?: string;
  evidencia_url?: string;
  responsable?: string;
}


export type EstadoDeficiencia = 
  | 'Registrada'
  | 'Pendiente de revisión'
  | 'En atención'
  | 'Corregida'
  | 'Pendiente de verificación'
  | 'Cerrada'
  | 'Rechazada para corrección';

export interface Deficiencia {
  id_deficiencia: string;
  cod_linea: string;
  poste_n: string;
  fecha_inspeccion: string;
  tipo_deficiencia: string;
  descripcion: string;
  prioridad: Prioridad;
  evidencia_fotografica: string;
  evidencia_drive_id?: string;
  observaciones: string;
  usuario_responsable: string;
  estado: EstadoDeficiencia;
  fecha_cierre?: string;
}

export interface Termografia {
  id_termografia: string;
  id_poste?: string;
  cod_linea: string;
  poste_n: string;
  tipo_armado: string;
  conductor_calibre: string;
  conductor_n_fases: string;
  nivel_tension: string; // e.g. '60 kV'
  tipo_zona: string; // e.g. 'Costa - Salina', 'Rural', 'Urbana'
  temp_ambiente: number; // °C
  temp_max_componente: number; // °C
  emisividad: number; // e.g. 0.95
  delta_t: number; // temp_max - temp_ambiente
  hora: string;
  fecha: string;
  componente_falla: string;
  comentario: string;
  criticidad: 'Normal' | 'Alerta' | 'Emergencia';
  evidencia_url: string;
  inspector: string;
}

export interface EfectoCorona {
  id_corona: string;
  cod_linea: string;
  poste_n: string;
  tipo_armado: string;
  tipo_aislador: string;
  nivel_tension_kv: string;
  temp_c: string;
  humedad_pct: string;
  fase_r_ganancia: string;
  fase_r_conteo: number;
  fase_s_ganancia: string;
  fase_s_conteo: number;
  fase_t_ganancia: string;
  fase_t_conteo: number;
  fecha: string;
  hora: string;
  comentarios: string;
  situaciones: string[];
  evidencia_url: string;
  inspector: string;
}

export interface Poda {
  id_poda: string;
  cod_linea: string;
  poste_n: string;
  tipo_armado: string;
  tipo_aislador: string;
  nivel_tension_kv: string;
  fecha_ejecucion: string;
  ubicacion_referencia: string;
  punto_inicial: string;
  punto_final: string;
  algarrobo: number;
  palmera: number;
  ornamental: number;
  tamarindo: number;
  ponceana: number;
  otros: number;
  total_arboles: number;
  observaciones: string;
  fotografias: string[];
  contratista_responsable: string;
  estado: 'Programada' | 'En Ejecución' | 'Completada' | 'Verificada';
}

export interface Mantenimiento {
  id_mantenimiento: string;
  cod_linea: string;
  poste_n: string;
  fecha_ejecucion: string;
  tipo_mantenimiento: 'Preventivo' | 'Correctivo' | 'Rutinario' | 'Emergencia' | 'Estructural';
  actividad_realizada: string;
  orden_mantenimiento: string;
  observaciones: string;
  fotografias: string[];
  contratista_responsable: string;
  estado: 'Programado' | 'En Proceso' | 'Finalizado' | 'Aprobado';
  altera_estructuras?: boolean;
  detalle_reordenamiento?: string;
}

export type EstadoDMS = 
  | 'Pendiente'
  | 'Asignada'
  | 'En Levantamiento'
  | 'Levantada'
  | 'Verificada'
  | 'Cerrada';

export interface DMSItem {
  id_dms: string;
  cod_linea: string;
  poste_n: string;
  codigo_dms: string;
  descripcion: string;
  fecha_identificacion: string;
  prioridad: Prioridad;
  fuente: string; // e.g. OSINERGMIN, Inspección Interna
  orden_servicio: string;
  estado: EstadoDMS;
  observaciones: string;
  evidencias: string[];
}

export interface LevantamientoDMS {
  id_levantamiento: string;
  id_dms: string;
  cod_linea: string;
  poste_n: string;
  fecha_ejecucion: string;
  descripcion_trabajo: string;
  orden_servicio: string;
  fotografias: string[];
  observaciones: string;
  contratista_responsable: string;
  estado: 'Registrado' | 'Aceptado por Supervisor' | 'Rechazado';
}

export interface InspeccionCierreDMS {
  id_inspeccion_cierre: string;
  id_dms: string;
  id_levantamiento: string;
  cod_linea: string;
  poste_n: string;
  fecha_inspeccion: string;
  inspector: string;
  resultado: 'Levantamiento conforme' | 'Levantamiento no conforme' | 'Requiere nueva intervención';
  observaciones: string;
  evidencias_fotograficas: string[];
  estado_final: 'Cerrada' | 'En Corrección' | 'Pendiente';
}

export interface EvidenciaFotografica {
  id_evidencia: string;
  id_actividad: string;
  tipo_actividad: 'Deficiencia' | 'Termografía' | 'Efecto Corona' | 'Poda' | 'Mantenimiento' | 'DMS' | 'Estructura';
  cod_linea: string;
  poste_n: string;
  drive_file_id?: string;
  enlace_drive?: string;
  tipo_foto: 'Antes' | 'Durante' | 'Después' | 'Detalle' | 'UV_Corona' | 'Termograma';
  fecha_registro: string;
  usuario_responsable: string;
  descripcion: string;
  url: string; // Data URL or Web link
}

export interface AuditoriaRegistro {
  id_auditoria: string;
  usuario: string;
  rol: string;
  fecha: string; // YYYY-MM-DD America/Lima
  hora: string; // HH:mm:ss America/Lima
  accion: 'CREACION' | 'EDICION' | 'DESACTIVACION' | 'ELIMINACION' | 'SINCRONIZACION' | 'IMPORTACION' | 'CIERRE_DMS' | 'REORDENAMIENTO';
  modulo: string;
  id_registro: string;
  cod_linea: string;
  estructura: string;
  valores_anteriores: string;
  valores_nuevos: string;
  origen: 'Web' | 'Google Drive' | 'Importación Excel' | 'Automático';
  resultado: 'Exitoso' | 'Fallido' | 'Conflicto';
  sync_id: string;
}

export interface ConfiguracionDrive {
  sheet_lineas_id: string;
  sheet_lineas_url: string;
  sheet_usuarios_id?: string;
  sheet_usuarios_url?: string;
  drive_folder_id: string;
  apps_script_url: string;
  auto_sync_interval: number; // minutes, 0 = off
  last_sync_time: string;
  sync_status: 'Conectado' | 'Desconectado' | 'Sincronizando' | 'Error';
  error_message?: string;
}

export interface ConflictoRegistro {
  id_conflicto: string;
  modulo: string;
  id_registro: string;
  campo: string;
  valor_local: string;
  valor_drive: string;
  fecha_deteccion: string;
  resuelto: boolean;
  resolucion?: 'Local' | 'Drive';
}
