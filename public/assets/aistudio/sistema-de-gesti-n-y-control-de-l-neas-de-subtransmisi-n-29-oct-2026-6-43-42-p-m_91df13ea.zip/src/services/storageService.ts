import seedData from '../data/seedData.json';
import {
  CATALOGO_DEFICIENCIAS,
  CATALOGO_SITUACIONES_CORONA,
  INITIAL_USUARIOS,
  INITIAL_DEFICIENCIAS,
  INITIAL_TERMOGRAFIA,
  INITIAL_PODAS,
  INITIAL_DMS,
  INITIAL_LEVANTAMIENTOS,
  INITIAL_INSPECCIONES_CIERRE
} from '../data/catalogs';
import {
  LineaSubtransmision,
  Estructura,
  EfectoCorona,
  Deficiencia,
  Termografia,
  Poda,
  Mantenimiento,
  DMSItem,
  LevantamientoDMS,
  InspeccionCierreDMS,
  Usuario,
  AuditoriaRegistro,
  ConfiguracionDrive,
  EvidenciaFotografica,
  ConflictoRegistro
} from '../types';
import { realtimeService } from './realtimeService';

const STORAGE_KEYS = {
  LINEAS: 'st_lineas_v1',
  ESTRUCTURAS: 'st_estructuras_v1',
  CORONA: 'st_corona_v1',
  DEFICIENCIAS: 'st_deficiencias_v1',
  TERMOGRAFIA: 'st_termografia_v1',
  PODAS: 'st_podas_v1',
  MANTENIMIENTO: 'st_mantenimiento_v1',
  DMS: 'st_dms_v1',
  LEVANTAMIENTOS: 'st_levantamientos_v1',
  INSPECCIONES: 'st_inspecciones_v1',
  USUARIOS: 'st_usuarios_v1',
  AUDITORIA: 'st_auditoria_v1',
  EVIDENCIAS: 'st_evidencias_v1',
  CONFIG: 'st_config_drive_v1',
  CONFLICTOS: 'st_conflictos_v1',
  CURRENT_USER: 'st_current_user_v1',
  SITUACIONES_CORONA: 'st_situaciones_corona_v1'
};

function getLimaDateTime(): { fecha: string; hora: string } {
  try {
    const now = new Date();
    const formatterFecha = new Intl.DateTimeFormat('es-PE', {
      timeZone: 'America/Lima',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
    const formatterHora = new Intl.DateTimeFormat('es-PE', {
      timeZone: 'America/Lima',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
    const parts = formatterFecha.formatToParts(now);
    const day = parts.find(p => p.type === 'day')?.value || '29';
    const month = parts.find(p => p.type === 'month')?.value || '10';
    const year = parts.find(p => p.type === 'year')?.value || '2026';
    return {
      fecha: `${year}-${month}-${day}`,
      hora: formatterHora.format(now)
    };
  } catch {
    const d = new Date();
    return {
      fecha: d.toISOString().split('T')[0],
      hora: d.toTimeString().split(' ')[0]
    };
  }
}

class StorageService {
  private lineas: LineaSubtransmision[] = [];
  private estructuras: Estructura[] = [];
  private corona: EfectoCorona[] = [];
  private deficiencias: Deficiencia[] = [];
  private termografia: Termografia[] = [];
  private podas: Poda[] = [];
  private mantenimiento: Mantenimiento[] = [];
  private dms: DMSItem[] = [];
  private levantamientos: LevantamientoDMS[] = [];
  private inspecciones: InspeccionCierreDMS[] = [];
  private usuarios: Usuario[] = [];
  private auditoria: AuditoriaRegistro[] = [];
  private evidencias: EvidenciaFotografica[] = [];
  private conflictos: ConflictoRegistro[] = [];
  private situacionesCorona: string[] = [];
  private config: ConfiguracionDrive = {
    sheet_lineas_id: '1QSIdzdBvHzjauw6jKX8lMGQuurrlsQDSCI5jZCFHW5Y',
    sheet_lineas_url: 'https://docs.google.com/spreadsheets/d/1QSIdzdBvHzjauw6jKX8lMGQuurrlsQDSCI5jZCFHW5Y/edit?gid=0#gid=0',
    sheet_usuarios_id: '1ImWOATNSbkIFIefgu1em8wvPWMv_M3FX',
    sheet_usuarios_url: 'https://docs.google.com/spreadsheets/d/1ImWOATNSbkIFIefgu1em8wvPWMv_M3FX/edit?rtpof=true',
    drive_folder_id: '1A9x_DRIVE_FOLDER_SUBTRANSMISION',
    apps_script_url: '',
    auto_sync_interval: 15,
    last_sync_time: '2026-10-29 09:30:00',
    sync_status: 'Conectado'
  };
  private currentUser: Usuario = INITIAL_USUARIOS[0];

  constructor() {
    this.init();
    this.setupRealtimeSync();
  }

  private init() {
    // 1. Lineas
    const cachedLineas = localStorage.getItem(STORAGE_KEYS.LINEAS);
    if (cachedLineas) {
      try { this.lineas = JSON.parse(cachedLineas); } catch { this.lineas = seedData.lineas as LineaSubtransmision[]; }
    } else {
      this.lineas = seedData.lineas as LineaSubtransmision[];
      this.saveLineas();
    }

    // 2. Estructuras (Postes)
    const cachedEstructuras = localStorage.getItem(STORAGE_KEYS.ESTRUCTURAS);
    if (cachedEstructuras) {
      try { this.estructuras = JSON.parse(cachedEstructuras); } catch { this.estructuras = seedData.estructuras as Estructura[]; }
    } else {
      this.estructuras = seedData.estructuras as Estructura[];
      this.saveEstructuras();
    }

    // 3. Efecto Corona
    const cachedCorona = localStorage.getItem(STORAGE_KEYS.CORONA);
    if (cachedCorona) {
      try { this.corona = JSON.parse(cachedCorona); } catch { this.corona = seedData.corona as EfectoCorona[]; }
    } else {
      this.corona = seedData.corona as EfectoCorona[];
      this.saveCorona();
    }

    // 4. Deficiencias
    const cachedDef = localStorage.getItem(STORAGE_KEYS.DEFICIENCIAS);
    if (cachedDef) {
      try { this.deficiencias = JSON.parse(cachedDef); } catch { this.deficiencias = INITIAL_DEFICIENCIAS; }
    } else {
      this.deficiencias = INITIAL_DEFICIENCIAS;
      this.saveDeficiencias();
    }

    // 5. Termografia
    const cachedTerm = localStorage.getItem(STORAGE_KEYS.TERMOGRAFIA);
    if (cachedTerm) {
      try { this.termografia = JSON.parse(cachedTerm); } catch { this.termografia = INITIAL_TERMOGRAFIA; }
    } else {
      this.termografia = INITIAL_TERMOGRAFIA;
      this.saveTermografia();
    }

    // 6. Podas
    const cachedPodas = localStorage.getItem(STORAGE_KEYS.PODAS);
    if (cachedPodas) {
      try { this.podas = JSON.parse(cachedPodas); } catch { this.podas = INITIAL_PODAS; }
    } else {
      this.podas = INITIAL_PODAS;
      this.savePodas();
    }

    // 7. Mantenimiento
    const cachedMant = localStorage.getItem(STORAGE_KEYS.MANTENIMIENTO);
    if (cachedMant) {
      try { this.mantenimiento = JSON.parse(cachedMant); } catch { this.mantenimiento = []; }
    } else {
      this.mantenimiento = [];
    }

    // 8. DMS
    const cachedDms = localStorage.getItem(STORAGE_KEYS.DMS);
    if (cachedDms) {
      try { this.dms = JSON.parse(cachedDms); } catch { this.dms = INITIAL_DMS; }
    } else {
      this.dms = INITIAL_DMS;
      this.saveDMS();
    }

    // 9. Levantamientos
    const cachedLev = localStorage.getItem(STORAGE_KEYS.LEVANTAMIENTOS);
    if (cachedLev) {
      try { this.levantamientos = JSON.parse(cachedLev); } catch { this.levantamientos = INITIAL_LEVANTAMIENTOS; }
    } else {
      this.levantamientos = INITIAL_LEVANTAMIENTOS;
      this.saveLevantamientos();
    }

    // 10. Inspecciones Cierre
    const cachedInsp = localStorage.getItem(STORAGE_KEYS.INSPECCIONES);
    if (cachedInsp) {
      try { this.inspecciones = JSON.parse(cachedInsp); } catch { this.inspecciones = INITIAL_INSPECCIONES_CIERRE; }
    } else {
      this.inspecciones = INITIAL_INSPECCIONES_CIERRE;
      this.saveInspecciones();
    }

    // 11. Usuarios
    const cachedUsers = localStorage.getItem(STORAGE_KEYS.USUARIOS);
    if (cachedUsers) {
      try { this.usuarios = JSON.parse(cachedUsers); } catch { this.usuarios = INITIAL_USUARIOS; }
    } else {
      this.usuarios = INITIAL_USUARIOS;
      this.saveUsuarios();
    }

    // 12. Current User
    const cachedCurrUser = localStorage.getItem('st_auth_user');
    if (cachedCurrUser) {
      try {
        this.currentUser = JSON.parse(cachedCurrUser);
      } catch {
        this.currentUser = this.usuarios[0] || INITIAL_USUARIOS[0];
      }
    }

    // 13. Auditoria
    const cachedAudit = localStorage.getItem(STORAGE_KEYS.AUDITORIA);
    if (cachedAudit) {
      try { this.auditoria = JSON.parse(cachedAudit); } catch { this.auditoria = []; }
    } else {
      const { fecha, hora } = getLimaDateTime();
      this.auditoria = [
        {
          id_auditoria: 'AUD-INIT-001',
          usuario: 'Sistema',
          rol: 'Administrador',
          fecha,
          hora,
          accion: 'IMPORTACION',
          modulo: 'INICIALIZACION',
          id_registro: 'DATASETS',
          cod_linea: 'TODAS',
          estructura: '-',
          valores_anteriores: 'Base vacía',
          valores_nuevos: `Cargadas 27 líneas, 1087 estructuras y 222 mediciones efecto corona`,
          origen: 'Importación Excel',
          resultado: 'Exitoso',
          sync_id: 'SYNC-001'
        }
      ];
      this.saveAuditoria();
    }

    // 14. Situaciones Corona
    const cachedSit = localStorage.getItem(STORAGE_KEYS.SITUACIONES_CORONA);
    if (cachedSit) {
      try { this.situacionesCorona = JSON.parse(cachedSit); } catch { this.situacionesCorona = CATALOGO_SITUACIONES_CORONA; }
    } else {
      this.situacionesCorona = CATALOGO_SITUACIONES_CORONA;
    }

    // 15. Config Drive
    const cachedConfig = localStorage.getItem(STORAGE_KEYS.CONFIG);
    if (cachedConfig) {
      try { this.config = { ...this.config, ...JSON.parse(cachedConfig) }; } catch { /* ignore */ }
    }

    // Fetch authoritative server state asynchronously on start
    this.fetchServerState();
  }

  private async fetchServerState() {
    try {
      const res = await fetch('/api/state');
      if (res.ok) {
        const serverState = await res.json();
        this.applyFullServerState(serverState);
      }
    } catch (e) {
      console.log('[StorageService] Local state initialized, server fetch pending');
    }
  }

  private setupRealtimeSync() {
    realtimeService.onStateUpdate((entity, action, data, fullState) => {
      if (action === 'init' && fullState) {
        this.applyFullServerState(fullState);
      } else {
        this.applyRemotePatch(entity, action, data);
      }
    });
  }

  public applyFullServerState(s: any) {
    if (s.lineas) { this.lineas = s.lineas; this.saveLineas(); }
    if (s.estructuras) { this.estructuras = s.estructuras; this.saveEstructuras(); }
    if (s.corona) { this.corona = s.corona; this.saveCorona(); }
    if (s.deficiencias) { this.deficiencias = s.deficiencias; this.saveDeficiencias(); }
    if (s.termografia) { this.termografia = s.termografia; this.saveTermografia(); }
    if (s.podas) { this.podas = s.podas; this.savePodas(); }
    if (s.mantenimiento) { this.mantenimiento = s.mantenimiento; this.saveMantenimiento(); }
    if (s.dms) { this.dms = s.dms; this.saveDMS(); }
    if (s.levantamientos) { this.levantamientos = s.levantamientos; this.saveLevantamientos(); }
    if (s.inspecciones) { this.inspecciones = s.inspecciones; this.saveInspecciones(); }
    if (s.usuarios) { this.usuarios = s.usuarios; this.saveUsuarios(); }
    if (s.auditoria) { this.auditoria = s.auditoria; this.saveAuditoria(); }
    if (s.config) { this.config = { ...this.config, ...s.config }; }
  }

  public applyRemotePatch(entity: string, action: string, data: any) {
    switch (entity) {
      case 'lineas':
        if (action === 'create') {
          if (!this.lineas.some(l => l.cod_linea === data.cod_linea)) this.lineas.push(data);
        } else if (action === 'update' || action === 'deactivate') {
          const idx = this.lineas.findIndex(l => l.cod_linea === data.cod_linea);
          if (idx >= 0) this.lineas[idx] = { ...this.lineas[idx], ...data };
        }
        this.saveLineas();
        break;

      case 'estructuras':
        if (action === 'create') {
          const exists = this.estructuras.some(e => e.id_poste === data.id_poste);
          if (!exists) this.estructuras.push(data);
        } else if (action === 'update') {
          const idx = this.estructuras.findIndex(e => e.id_poste === data.id_poste);
          if (idx >= 0) this.estructuras[idx] = { ...this.estructuras[idx], ...data };
        } else if (action === 'delete') {
          const idx = this.estructuras.findIndex(e => e.cod_linea === data.cod_linea && e.poste_n === data.poste_n);
          if (idx >= 0) this.estructuras.splice(idx, 1);
        } else if (action === 'batch') {
          this.estructuras = data;
        }
        this.saveEstructuras();
        break;

      case 'corona':
        if (action === 'create') {
          if (!this.corona.some(c => c.id_corona === data.id_corona)) this.corona.unshift(data);
        } else if (action === 'update') {
          const idx = this.corona.findIndex(c => c.id_corona === data.id_corona);
          if (idx >= 0) this.corona[idx] = { ...this.corona[idx], ...data };
        }
        this.saveCorona();
        break;

      case 'deficiencias':
        if (action === 'create') {
          if (!this.deficiencias.some(d => d.id_deficiencia === data.id_deficiencia)) this.deficiencias.unshift(data);
        } else if (action === 'update') {
          const idx = this.deficiencias.findIndex(d => d.id_deficiencia === data.id_deficiencia);
          if (idx >= 0) this.deficiencias[idx] = { ...this.deficiencias[idx], ...data };
        }
        this.saveDeficiencias();
        break;

      case 'termografia':
        if (action === 'create') {
          if (!this.termografia.some(t => t.id_termografia === data.id_termografia)) this.termografia.unshift(data);
        } else if (action === 'update') {
          const idx = this.termografia.findIndex(t => t.id_termografia === data.id_termografia);
          if (idx >= 0) this.termografia[idx] = { ...this.termografia[idx], ...data };
        }
        this.saveTermografia();
        break;

      case 'podas':
        if (action === 'create') {
          if (!this.podas.some(p => p.id_poda === data.id_poda)) this.podas.unshift(data);
        } else if (action === 'update') {
          const idx = this.podas.findIndex(p => p.id_poda === data.id_poda);
          if (idx >= 0) this.podas[idx] = { ...this.podas[idx], ...data };
        }
        this.savePodas();
        break;

      case 'mantenimiento':
        if (action === 'create') {
          if (!this.mantenimiento.some(m => m.id_mantenimiento === data.id_mantenimiento)) this.mantenimiento.unshift(data);
        }
        this.saveMantenimiento();
        break;

      case 'dms':
        if (action === 'create') {
          if (!this.dms.some(d => d.id_dms === data.id_dms)) this.dms.unshift(data);
        } else if (action === 'update') {
          const idx = this.dms.findIndex(d => d.id_dms === data.id_dms);
          if (idx >= 0) this.dms[idx] = { ...this.dms[idx], ...data };
        } else if (action === 'batch') {
          this.importDMSBatch(data, false);
        }
        this.saveDMS();
        break;

      case 'levantamientos':
        if (action === 'create') {
          if (!this.levantamientos.some(l => l.id_levantamiento === data.id_levantamiento)) this.levantamientos.unshift(data);
          const dmsIdx = this.dms.findIndex(d => d.id_dms === data.id_dms);
          if (dmsIdx >= 0) this.dms[dmsIdx].estado = 'Levantada';
          this.saveDMS();
        }
        this.saveLevantamientos();
        break;

      case 'inspecciones':
        if (action === 'create') {
          if (!this.inspecciones.some(i => i.id_inspeccion_cierre === data.id_inspeccion_cierre)) this.inspecciones.unshift(data);
          const dmsIdx = this.dms.findIndex(d => d.id_dms === data.id_dms);
          if (dmsIdx >= 0) {
            this.dms[dmsIdx].estado = data.resultado === 'Levantamiento conforme' ? 'Cerrada' : 'En Levantamiento';
            this.saveDMS();
          }
        }
        this.saveInspecciones();
        break;

      case 'usuarios':
        if (action === 'create') {
          if (!this.usuarios.some(u => u.id_usuario === data.id_usuario)) this.usuarios.push(data);
        } else if (action === 'update') {
          const idx = this.usuarios.findIndex(u => u.id_usuario === data.id_usuario);
          if (idx >= 0) this.usuarios[idx] = { ...this.usuarios[idx], ...data };
        }
        this.saveUsuarios();
        break;
    }
  }

  // --- CURRENT USER & AUTH ---
  getCurrentUser(): Usuario {
    return this.currentUser;
  }

  setCurrentUser(userOrUsername: string | Usuario): boolean {
    if (typeof userOrUsername === 'string') {
      const found = this.usuarios.find(u => u.username === userOrUsername);
      if (found) {
        this.currentUser = found;
        localStorage.setItem('st_auth_user', JSON.stringify(found));
        realtimeService.identify(found);
        return true;
      }
      return false;
    } else {
      this.currentUser = userOrUsername;
      localStorage.setItem('st_auth_user', JSON.stringify(userOrUsername));
      realtimeService.identify(userOrUsername);
      return true;
    }
  }

  logout() {
    localStorage.removeItem('st_auth_token');
    localStorage.removeItem('st_auth_user');
  }

  canAccessLine(codLinea: string): boolean {
    if (this.currentUser.rol === 'Administrador') return true;
    if (this.currentUser.lineas_asignadas.includes('*')) return true;
    return this.currentUser.lineas_asignadas.includes(codLinea);
  }

  getAccessibleLines(): LineaSubtransmision[] {
    if (this.currentUser.rol === 'Administrador' || this.currentUser.lineas_asignadas.includes('*')) {
      return this.lineas;
    }
    return this.lineas.filter(l => this.currentUser.lineas_asignadas.includes(l.cod_linea));
  }

  // --- AUDITORIA ---
  getAuditoria(): AuditoriaRegistro[] {
    return this.auditoria;
  }

  recordAudit(params: Omit<AuditoriaRegistro, 'id_auditoria' | 'usuario' | 'rol' | 'fecha' | 'hora' | 'sync_id'> & { sync_id?: string }): AuditoriaRegistro {
    const { fecha, hora } = getLimaDateTime();
    const entry: AuditoriaRegistro = {
      id_auditoria: 'AUD-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      usuario: `${this.currentUser.nombres} ${this.currentUser.apellidos}`,
      rol: this.currentUser.rol,
      fecha,
      hora,
      accion: params.accion,
      modulo: params.modulo,
      id_registro: params.id_registro,
      cod_linea: params.cod_linea,
      estructura: params.estructura,
      valores_anteriores: params.valores_anteriores,
      valores_nuevos: params.valores_nuevos,
      origen: params.origen,
      resultado: params.resultado,
      sync_id: params.sync_id || 'LOCAL-SYNC'
    };
    this.auditoria.unshift(entry);
    this.saveAuditoria();
    return entry;
  }

  private saveAuditoria() {
    localStorage.setItem(STORAGE_KEYS.AUDITORIA, JSON.stringify(this.auditoria.slice(0, 1000)));
  }

  // --- LÍNEAS DE SUBTRANSMISIÓN ---
  getLineas(): LineaSubtransmision[] {
    return this.lineas;
  }

  getLineaByCode(codLinea: string): LineaSubtransmision | undefined {
    return this.lineas.find(l => l.cod_linea === codLinea);
  }

  addLinea(linea: Omit<LineaSubtransmision, 'id_linea' | 'fecha_registro' | 'ultima_sincronizacion'>): { success: boolean; message: string; data?: LineaSubtransmision } {
    if (this.currentUser.rol === 'Contratista') {
      return { success: false, message: 'Permiso denegado: El contratista no puede registrar líneas.' };
    }
    const cleanCode = linea.cod_linea.trim().toUpperCase();
    if (this.lineas.some(l => l.cod_linea.toUpperCase() === cleanCode)) {
      return { success: false, message: `Error: La línea con código "${cleanCode}" ya existe en el sistema.` };
    }
    const { fecha, hora } = getLimaDateTime();
    const newLine: LineaSubtransmision = {
      ...linea,
      cod_linea: cleanCode,
      id_linea: 'LIN-' + String(this.lineas.length + 1).padStart(3, '0'),
      estado: linea.estado || 'Activo',
      fecha_registro: fecha,
      ultima_sincronizacion: `${fecha} ${hora}`
    };
    this.lineas.push(newLine);
    this.saveLineas();

    realtimeService.mutate('lineas', 'create', newLine);

    this.recordAudit({
      accion: 'CREACION',
      modulo: 'LÍNEAS',
      id_registro: newLine.id_linea,
      cod_linea: newLine.cod_linea,
      estructura: '-',
      valores_anteriores: 'N/A',
      valores_nuevos: JSON.stringify(newLine),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return { success: true, message: `Línea ${newLine.cod_linea} registrada exitosamente.`, data: newLine };
  }

  updateLinea(codLinea: string, updates: Partial<LineaSubtransmision>): { success: boolean; message: string; data?: LineaSubtransmision } {
    if (this.currentUser.rol === 'Contratista') {
      return { success: false, message: 'Permiso denegado: Los contratistas no tienen autorización para modificar líneas.' };
    }
    const index = this.lineas.findIndex(l => l.cod_linea === codLinea);
    if (index === -1) {
      return { success: false, message: `Línea ${codLinea} no encontrada.` };
    }
    const prev = { ...this.lineas[index] };
    const { fecha, hora } = getLimaDateTime();
    this.lineas[index] = {
      ...this.lineas[index],
      ...updates,
      cod_linea: codLinea,
      ultima_sincronizacion: `${fecha} ${hora}`
    };
    this.saveLineas();

    realtimeService.mutate('lineas', 'update', this.lineas[index]);

    this.recordAudit({
      accion: 'EDICION',
      modulo: 'LÍNEAS',
      id_registro: this.lineas[index].id_linea,
      cod_linea: codLinea,
      estructura: '-',
      valores_anteriores: JSON.stringify(prev),
      valores_nuevos: JSON.stringify(this.lineas[index]),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return { success: true, message: `Línea ${codLinea} actualizada correctamente.`, data: this.lineas[index] };
  }

  deactivateOrDeleteLinea(codLinea: string, forceDelete = false): { success: boolean; message: string; actionTaken: 'DESACTIVADA' | 'ELIMINADA' } {
    if (this.currentUser.rol !== 'Administrador') {
      throw new Error('Solo el Administrador puede desactivar o eliminar líneas.');
    }
    const index = this.lineas.findIndex(l => l.cod_linea === codLinea);
    if (index === -1) return { success: false, message: `Línea ${codLinea} no existe.`, actionTaken: 'DESACTIVADA' };

    const countEstructuras = this.estructuras.filter(e => e.cod_linea === codLinea).length;
    const countDeficiencias = this.deficiencias.filter(d => d.cod_linea === codLinea).length;
    const countCorona = this.corona.filter(c => c.cod_linea === codLinea).length;
    const countTotal = countEstructuras + countDeficiencias + countCorona;

    if (countTotal > 0 && !forceDelete) {
      this.lineas[index].estado = 'Inactivo';
      this.saveLineas();

      realtimeService.mutate('lineas', 'deactivate', { cod_linea: codLinea, estado: 'Inactivo' });

      this.recordAudit({
        accion: 'DESACTIVACION',
        modulo: 'LÍNEAS',
        id_registro: this.lineas[index].id_linea,
        cod_linea: codLinea,
        estructura: '-',
        valores_anteriores: 'Activo',
        valores_nuevos: 'Inactivo (Desactivación lógica por ' + countTotal + ' registros dependientes)',
        origen: 'Web',
        resultado: 'Exitoso'
      });
      return {
        success: true,
        message: `La línea ${codLinea} tiene ${countEstructuras} estructuras asociadas. Ha sido DESACTIVADA lógicamente para preservar el historial.`,
        actionTaken: 'DESACTIVADA'
      };
    } else {
      const removed = this.lineas.splice(index, 1)[0];
      this.saveLineas();
      this.recordAudit({
        accion: 'ELIMINACION',
        modulo: 'LÍNEAS',
        id_registro: removed.id_linea,
        cod_linea: codLinea,
        estructura: '-',
        valores_anteriores: JSON.stringify(removed),
        valores_nuevos: 'ELIMINADO',
        origen: 'Web',
        resultado: 'Exitoso'
      });
      return {
        success: true,
        message: `Línea ${codLinea} eliminada permanentemente.`,
        actionTaken: 'ELIMINADA'
      };
    }
  }

  private saveLineas() {
    localStorage.setItem(STORAGE_KEYS.LINEAS, JSON.stringify(this.lineas));
  }

  // --- ESTRUCTURAS (POSTES) ---
  getEstructuras(codLinea?: string): Estructura[] {
    if (codLinea) {
      return this.estructuras.filter(e => e.cod_linea === codLinea);
    }
    return this.estructuras;
  }

  private parsePosteNumber(posteN: string): { num: number; suffix: string } {
    const trimmed = (posteN || '').trim();
    const match = trimmed.match(/^(\d+)(.*)$/);
    if (match) {
      return { num: parseInt(match[1], 10), suffix: match[2] };
    }
    return { num: 999999, suffix: trimmed };
  }

  insertStructureWithShift(
    codLinea: string,
    targetPosteN: string,
    data: Omit<Estructura, 'id_poste' | 'cod_linea' | 'poste_n'>,
    shiftSubsequent = true
  ): { success: boolean; message: string; structure?: Estructura } {
    const targetParsed = this.parsePosteNumber(targetPosteN);
    let shiftedCount = 0;

    if (shiftSubsequent && targetParsed.num !== 999999) {
      const lineStructs = this.estructuras.filter(e => e.cod_linea === codLinea);
      lineStructs.sort((a, b) => this.parsePosteNumber(b.poste_n).num - this.parsePosteNumber(a.poste_n).num);

      lineStructs.forEach(st => {
        const p = this.parsePosteNumber(st.poste_n);
        if (p.num >= targetParsed.num) {
          st.poste_n = String(p.num + 1) + p.suffix;
          shiftedCount++;
        }
      });
    }

    const newStruct: Estructura = {
      ...data,
      id_poste: 'POS-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      cod_linea: codLinea,
      poste_n: targetPosteN,
      estado: data.estado || 'Operativo'
    };

    this.estructuras.push(newStruct);
    this.saveEstructuras();

    realtimeService.mutate('estructuras', 'create', newStruct, shiftSubsequent);

    this.recordAudit({
      accion: 'REORDENAMIENTO',
      modulo: 'ESTRUCTURAS',
      id_registro: newStruct.id_poste,
      cod_linea: codLinea,
      estructura: targetPosteN,
      valores_anteriores: 'N/A',
      valores_nuevos: `Nueva estructura insertada en POSTE_N=${targetPosteN}. ${shiftedCount} estructuras subsiguientes desplazadas +1`,
      origen: 'Web',
      resultado: 'Exitoso'
    });

    return {
      success: true,
      message: `Estructura ${targetPosteN} insertada en ${codLinea}.${shiftedCount > 0 ? ` Se desplazaron ${shiftedCount} estructuras subsiguientes.` : ''}`,
      structure: newStruct
    };
  }

  deleteStructureWithShift(codLinea: string, targetPosteN: string, shiftSubsequent = true): { success: boolean; message: string } {
    const index = this.estructuras.findIndex(e => e.cod_linea === codLinea && e.poste_n === targetPosteN);
    if (index === -1) return { success: false, message: `Estructura ${targetPosteN} no encontrada en línea ${codLinea}.` };

    const deleted = this.estructuras.splice(index, 1)[0];
    const targetParsed = this.parsePosteNumber(targetPosteN);
    let shiftedCount = 0;

    if (shiftSubsequent && targetParsed.num !== 999999) {
      this.estructuras.forEach(st => {
        if (st.cod_linea === codLinea) {
          const p = this.parsePosteNumber(st.poste_n);
          if (p.num > targetParsed.num) {
            st.poste_n = String(p.num - 1) + p.suffix;
            shiftedCount++;
          }
        }
      });
    }

    this.saveEstructuras();
    realtimeService.mutate('estructuras', 'delete', { cod_linea: codLinea, poste_n: targetPosteN }, shiftSubsequent);

    this.recordAudit({
      accion: 'REORDENAMIENTO',
      modulo: 'ESTRUCTURAS',
      id_registro: deleted.id_poste,
      cod_linea: codLinea,
      estructura: targetPosteN,
      valores_anteriores: JSON.stringify(deleted),
      valores_nuevos: `Estructura eliminada. ${shiftedCount} estructuras subsiguientes desplazadas -1`,
      origen: 'Web',
      resultado: 'Exitoso'
    });

    return {
      success: true,
      message: `Estructura ${targetPosteN} eliminada.${shiftedCount > 0 ? ` Se reordenaron ${shiftedCount} estructuras posteriores.` : ''}`
    };
  }

  updateEstructura(idPoste: string, updates: Partial<Estructura>): { success: boolean; message: string } {
    const idx = this.estructuras.findIndex(e => e.id_poste === idPoste);
    if (idx === -1) return { success: false, message: 'Estructura no encontrada.' };
    const prev = { ...this.estructuras[idx] };
    this.estructuras[idx] = { ...this.estructuras[idx], ...updates };
    this.saveEstructuras();

    realtimeService.mutate('estructuras', 'update', this.estructuras[idx]);

    this.recordAudit({
      accion: 'EDICION',
      modulo: 'ESTRUCTURAS',
      id_registro: idPoste,
      cod_linea: this.estructuras[idx].cod_linea,
      estructura: this.estructuras[idx].poste_n,
      valores_anteriores: JSON.stringify(prev),
      valores_nuevos: JSON.stringify(this.estructuras[idx]),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return { success: true, message: 'Estructura actualizada correctamente.' };
  }

  importEstructurasBatch(newStructs: Estructura[], mode: 'merge' | 'replace'): { success: boolean; message: string; count: number } {
    if (mode === 'replace') {
      this.estructuras = newStructs;
    } else {
      for (const ns of newStructs) {
        const existingIdx = this.estructuras.findIndex(
          e => e.cod_linea === ns.cod_linea && e.poste_n.trim().toLowerCase() === ns.poste_n.trim().toLowerCase()
        );
        if (existingIdx >= 0) {
          this.estructuras[existingIdx] = { ...this.estructuras[existingIdx], ...ns };
        } else {
          this.estructuras.push(ns);
        }
      }
    }
    this.saveEstructuras();
    realtimeService.mutate('estructuras', 'batch', this.estructuras);

    this.recordAudit({
      accion: 'IMPORTACION',
      modulo: 'ESTRUCTURAS',
      id_registro: 'BATCH',
      cod_linea: 'VARIAS',
      estructura: '-',
      valores_anteriores: 'N/A',
      valores_nuevos: `Importadas ${newStructs.length} estructuras desde Excel (Modo: ${mode})`,
      origen: 'Importación Excel',
      resultado: 'Exitoso'
    });
    return { success: true, message: `Se importaron ${newStructs.length} estructuras exitosamente.`, count: newStructs.length };
  }

  private saveEstructuras() {
    localStorage.setItem(STORAGE_KEYS.ESTRUCTURAS, JSON.stringify(this.estructuras));
  }

  // --- EFECTO CORONA ---
  getCorona(codLinea?: string): EfectoCorona[] {
    if (codLinea) {
      return this.corona.filter(c => c.cod_linea === codLinea);
    }
    return this.corona;
  }

  addCorona(item: Omit<EfectoCorona, 'id_corona'>): EfectoCorona {
    const newItem: EfectoCorona = {
      ...item,
      id_corona: 'COR-' + Math.random().toString(36).substring(2, 9).toUpperCase()
    };
    this.corona.unshift(newItem);
    this.saveCorona();

    realtimeService.mutate('corona', 'create', newItem);

    this.recordAudit({
      accion: 'CREACION',
      modulo: 'EFECTO_CORONA',
      id_registro: newItem.id_corona,
      cod_linea: newItem.cod_linea,
      estructura: newItem.poste_n,
      valores_anteriores: 'N/A',
      valores_nuevos: JSON.stringify(newItem),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return newItem;
  }

  updateCorona(idCorona: string, updates: Partial<EfectoCorona>): boolean {
    const idx = this.corona.findIndex(c => c.id_corona === idCorona);
    if (idx === -1) return false;
    const prev = { ...this.corona[idx] };
    this.corona[idx] = { ...this.corona[idx], ...updates };
    this.saveCorona();

    realtimeService.mutate('corona', 'update', this.corona[idx]);

    this.recordAudit({
      accion: 'EDICION',
      modulo: 'EFECTO_CORONA',
      id_registro: idCorona,
      cod_linea: this.corona[idx].cod_linea,
      estructura: this.corona[idx].poste_n,
      valores_anteriores: JSON.stringify(prev),
      valores_nuevos: JSON.stringify(this.corona[idx]),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return true;
  }

  getSituacionesCorona(): string[] {
    return this.situacionesCorona;
  }

  addSituacionCorona(sit: string) {
    if (!this.situacionesCorona.includes(sit.trim())) {
      this.situacionesCorona.push(sit.trim());
      localStorage.setItem(STORAGE_KEYS.SITUACIONES_CORONA, JSON.stringify(this.situacionesCorona));
    }
  }

  private saveCorona() {
    localStorage.setItem(STORAGE_KEYS.CORONA, JSON.stringify(this.corona));
  }

  // --- DEFICIENCIAS ---
  getDeficiencias(codLinea?: string): Deficiencia[] {
    if (codLinea) {
      return this.deficiencias.filter(d => d.cod_linea === codLinea);
    }
    return this.deficiencias;
  }

  addDeficiencia(def: Omit<Deficiencia, 'id_deficiencia'>): Deficiencia {
    const newItem: Deficiencia = {
      ...def,
      id_deficiencia: 'DEF-' + String(this.deficiencias.length + 1).padStart(4, '0')
    };
    this.deficiencias.unshift(newItem);
    this.saveDeficiencias();

    realtimeService.mutate('deficiencias', 'create', newItem);

    this.recordAudit({
      accion: 'CREACION',
      modulo: 'DEFICIENCIAS',
      id_registro: newItem.id_deficiencia,
      cod_linea: newItem.cod_linea,
      estructura: newItem.poste_n,
      valores_anteriores: 'N/A',
      valores_nuevos: JSON.stringify(newItem),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return newItem;
  }

  updateDeficiencia(id: string, updates: Partial<Deficiencia>): boolean {
    const idx = this.deficiencias.findIndex(d => d.id_deficiencia === id);
    if (idx === -1) return false;
    const prev = { ...this.deficiencias[idx] };
    this.deficiencias[idx] = { ...this.deficiencias[idx], ...updates };
    this.saveDeficiencias();

    realtimeService.mutate('deficiencias', 'update', this.deficiencias[idx]);

    this.recordAudit({
      accion: 'EDICION',
      modulo: 'DEFICIENCIAS',
      id_registro: id,
      cod_linea: this.deficiencias[idx].cod_linea,
      estructura: this.deficiencias[idx].poste_n,
      valores_anteriores: JSON.stringify(prev),
      valores_nuevos: JSON.stringify(this.deficiencias[idx]),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return true;
  }

  private saveDeficiencias() {
    localStorage.setItem(STORAGE_KEYS.DEFICIENCIAS, JSON.stringify(this.deficiencias));
  }

  // --- TERMOGRAFÍA ---
  getTermografia(codLinea?: string): Termografia[] {
    if (codLinea) return this.termografia.filter(t => t.cod_linea === codLinea);
    return this.termografia;
  }

  addTermografia(term: Omit<Termografia, 'id_termografia'>): Termografia {
    const newItem: Termografia = {
      ...term,
      id_termografia: 'TRM-' + String(this.termografia.length + 1).padStart(4, '0')
    };
    this.termografia.unshift(newItem);
    this.saveTermografia();

    realtimeService.mutate('termografia', 'create', newItem);

    this.recordAudit({
      accion: 'CREACION',
      modulo: 'TERMOGRAFIA',
      id_registro: newItem.id_termografia,
      cod_linea: newItem.cod_linea,
      estructura: newItem.poste_n,
      valores_anteriores: 'N/A',
      valores_nuevos: JSON.stringify(newItem),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return newItem;
  }

  updateTermografia(id: string, updates: Partial<Termografia>): boolean {
    const idx = this.termografia.findIndex(t => t.id_termografia === id);
    if (idx === -1) return false;
    const prev = { ...this.termografia[idx] };
    this.termografia[idx] = { ...this.termografia[idx], ...updates };
    this.saveTermografia();

    realtimeService.mutate('termografia', 'update', this.termografia[idx]);

    this.recordAudit({
      accion: 'EDICION',
      modulo: 'TERMOGRAFIA',
      id_registro: id,
      cod_linea: this.termografia[idx].cod_linea,
      estructura: this.termografia[idx].poste_n,
      valores_anteriores: JSON.stringify(prev),
      valores_nuevos: JSON.stringify(this.termografia[idx]),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return true;
  }

  private saveTermografia() {
    localStorage.setItem(STORAGE_KEYS.TERMOGRAFIA, JSON.stringify(this.termografia));
  }

  // --- PODAS ---
  getPodas(codLinea?: string): Poda[] {
    if (codLinea) return this.podas.filter(p => p.cod_linea === codLinea);
    return this.podas;
  }

  addPoda(poda: Omit<Poda, 'id_poda' | 'total_arboles'>): Poda {
    const total = (poda.algarrobo || 0) + (poda.palmera || 0) + (poda.ornamental || 0) + (poda.tamarindo || 0) + (poda.ponceana || 0) + (poda.otros || 0);
    const newItem: Poda = {
      ...poda,
      total_arboles: total,
      id_poda: 'POD-' + String(this.podas.length + 1).padStart(4, '0')
    };
    this.podas.unshift(newItem);
    this.savePodas();

    realtimeService.mutate('podas', 'create', newItem);

    this.recordAudit({
      accion: 'CREACION',
      modulo: 'PODAS',
      id_registro: newItem.id_poda,
      cod_linea: newItem.cod_linea,
      estructura: newItem.poste_n,
      valores_anteriores: 'N/A',
      valores_nuevos: JSON.stringify(newItem),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return newItem;
  }

  updatePoda(id: string, updates: Partial<Poda>): boolean {
    const idx = this.podas.findIndex(p => p.id_poda === id);
    if (idx === -1) return false;
    const prev = { ...this.podas[idx] };
    const merged = { ...this.podas[idx], ...updates };
    merged.total_arboles = (merged.algarrobo || 0) + (merged.palmera || 0) + (merged.ornamental || 0) + (merged.tamarindo || 0) + (merged.ponceana || 0) + (merged.otros || 0);
    this.podas[idx] = merged;
    this.savePodas();

    realtimeService.mutate('podas', 'update', this.podas[idx]);

    this.recordAudit({
      accion: 'EDICION',
      modulo: 'PODAS',
      id_registro: id,
      cod_linea: merged.cod_linea,
      estructura: merged.poste_n,
      valores_anteriores: JSON.stringify(prev),
      valores_nuevos: JSON.stringify(merged),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return true;
  }

  private savePodas() {
    localStorage.setItem(STORAGE_KEYS.PODAS, JSON.stringify(this.podas));
  }

  // --- MANTENIMIENTO ---
  getMantenimiento(codLinea?: string): Mantenimiento[] {
    if (codLinea) return this.mantenimiento.filter(m => m.cod_linea === codLinea);
    return this.mantenimiento;
  }

  addMantenimiento(mant: Omit<Mantenimiento, 'id_mantenimiento'>): Mantenimiento {
    const newItem: Mantenimiento = {
      ...mant,
      id_mantenimiento: 'MNT-' + String(this.mantenimiento.length + 1).padStart(4, '0')
    };
    this.mantenimiento.unshift(newItem);
    this.saveMantenimiento();

    realtimeService.mutate('mantenimiento', 'create', newItem);

    this.recordAudit({
      accion: 'CREACION',
      modulo: 'MANTENIMIENTO',
      id_registro: newItem.id_mantenimiento,
      cod_linea: newItem.cod_linea,
      estructura: newItem.poste_n,
      valores_anteriores: 'N/A',
      valores_nuevos: JSON.stringify(newItem),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return newItem;
  }

  private saveMantenimiento() {
    localStorage.setItem(STORAGE_KEYS.MANTENIMIENTO, JSON.stringify(this.mantenimiento));
  }

  // --- DMS ---
  getDMS(codLinea?: string): DMSItem[] {
    if (codLinea) return this.dms.filter(d => d.cod_linea === codLinea);
    return this.dms;
  }

  addDMS(item: Omit<DMSItem, 'id_dms'>): DMSItem {
    const newItem: DMSItem = {
      ...item,
      id_dms: 'DMS-' + Math.random().toString(36).substring(2, 9).toUpperCase()
    };
    this.dms.unshift(newItem);
    this.saveDMS();

    realtimeService.mutate('dms', 'create', newItem);

    this.recordAudit({
      accion: 'CREACION',
      modulo: 'DMS',
      id_registro: newItem.id_dms,
      cod_linea: newItem.cod_linea,
      estructura: newItem.poste_n,
      valores_anteriores: 'N/A',
      valores_nuevos: JSON.stringify(newItem),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return newItem;
  }

  updateDMS(id: string, updates: Partial<DMSItem>): boolean {
    const idx = this.dms.findIndex(d => d.id_dms === id);
    if (idx === -1) return false;
    const prev = { ...this.dms[idx] };
    this.dms[idx] = { ...this.dms[idx], ...updates };
    this.saveDMS();

    realtimeService.mutate('dms', 'update', this.dms[idx]);

    this.recordAudit({
      accion: 'EDICION',
      modulo: 'DMS',
      id_registro: id,
      cod_linea: this.dms[idx].cod_linea,
      estructura: this.dms[idx].poste_n,
      valores_anteriores: JSON.stringify(prev),
      valores_nuevos: JSON.stringify(this.dms[idx]),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return true;
  }

  importDMSBatch(items: DMSItem[], broadcast = true): number {
    let count = 0;
    for (const item of items) {
      const existing = this.dms.findIndex(d => d.codigo_dms && d.codigo_dms === item.codigo_dms);
      if (existing >= 0) {
        this.dms[existing] = { ...this.dms[existing], ...item };
      } else {
        this.dms.push(item);
      }
      count++;
    }
    this.saveDMS();

    if (broadcast) {
      realtimeService.mutate('dms', 'batch', items);
    }

    this.recordAudit({
      accion: 'IMPORTACION',
      modulo: 'DMS',
      id_registro: 'BATCH',
      cod_linea: 'VARIAS',
      estructura: '-',
      valores_anteriores: 'N/A',
      valores_nuevos: `Importados ${count} registros DMS desde archivo Excel`,
      origen: 'Importación Excel',
      resultado: 'Exitoso'
    });
    return count;
  }

  private saveDMS() {
    localStorage.setItem(STORAGE_KEYS.DMS, JSON.stringify(this.dms));
  }

  // --- LEVANTAMIENTOS DMS ---
  getLevantamientos(idDms?: string): LevantamientoDMS[] {
    if (idDms) return this.levantamientos.filter(l => l.id_dms === idDms);
    return this.levantamientos;
  }

  addLevantamiento(lev: Omit<LevantamientoDMS, 'id_levantamiento'>): LevantamientoDMS {
    const newItem: LevantamientoDMS = {
      ...lev,
      id_levantamiento: 'LEV-' + Math.random().toString(36).substring(2, 9).toUpperCase()
    };
    this.levantamientos.unshift(newItem);
    this.saveLevantamientos();

    this.updateDMS(lev.id_dms, { estado: 'Levantada' });

    realtimeService.mutate('levantamientos', 'create', newItem);

    this.recordAudit({
      accion: 'CREACION',
      modulo: 'LEVANTAMIENTO_DMS',
      id_registro: newItem.id_levantamiento,
      cod_linea: newItem.cod_linea,
      estructura: newItem.poste_n,
      valores_anteriores: 'Pendiente/En Levantamiento',
      valores_nuevos: `Levantamiento registrado por ${newItem.contratista_responsable}`,
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return newItem;
  }

  private saveLevantamientos() {
    localStorage.setItem(STORAGE_KEYS.LEVANTAMIENTOS, JSON.stringify(this.levantamientos));
  }

  // --- INSPECCIONES Y CIERRE DMS ---
  getInspecciones(idDms?: string): InspeccionCierreDMS[] {
    if (idDms) return this.inspecciones.filter(i => i.id_dms === idDms);
    return this.inspecciones;
  }

  addInspeccionCierre(insp: Omit<InspeccionCierreDMS, 'id_inspeccion_cierre'>): InspeccionCierreDMS {
    if (this.currentUser.rol === 'Contratista') {
      throw new Error('Permiso denegado: El contratista no puede realizar inspecciones ni cierre definitivo de DMS.');
    }
    const newItem: InspeccionCierreDMS = {
      ...insp,
      id_inspeccion_cierre: 'INSP-' + Math.random().toString(36).substring(2, 9).toUpperCase()
    };
    this.inspecciones.unshift(newItem);
    this.saveInspecciones();

    if (insp.resultado === 'Levantamiento conforme') {
      this.updateDMS(insp.id_dms, { estado: 'Cerrada' });
    } else {
      this.updateDMS(insp.id_dms, { estado: 'En Levantamiento' });
    }

    realtimeService.mutate('inspecciones', 'create', newItem);

    this.recordAudit({
      accion: insp.resultado === 'Levantamiento conforme' ? 'CIERRE_DMS' : 'EDICION',
      modulo: 'INSPECCION_DMS',
      id_registro: newItem.id_inspeccion_cierre,
      cod_linea: newItem.cod_linea,
      estructura: newItem.poste_n,
      valores_anteriores: 'Levantada',
      valores_nuevos: `Inspección de cierre: ${newItem.resultado}`,
      origen: 'Web',
      resultado: 'Exitoso'
    });

    return newItem;
  }

  private saveInspecciones() {
    localStorage.setItem(STORAGE_KEYS.INSPECCIONES, JSON.stringify(this.inspecciones));
  }

  // --- USUARIOS ---
  getUsuarios(): Usuario[] {
    return this.usuarios;
  }

  addUsuario(usr: Omit<Usuario, 'id_usuario' | 'fecha_creacion'>): Usuario {
    if (this.currentUser.rol !== 'Administrador') {
      throw new Error('Solo el Administrador puede crear nuevos usuarios.');
    }
    const { fecha } = getLimaDateTime();
    const newUser: Usuario = {
      ...usr,
      id_usuario: 'USR-' + String(this.usuarios.length + 1).padStart(3, '0'),
      fecha_creacion: fecha
    };
    this.usuarios.push(newUser);
    this.saveUsuarios();

    realtimeService.mutate('usuarios', 'create', newUser);

    this.recordAudit({
      accion: 'CREACION',
      modulo: 'USUARIOS',
      id_registro: newUser.id_usuario,
      cod_linea: '-',
      estructura: '-',
      valores_anteriores: 'N/A',
      valores_nuevos: JSON.stringify(newUser),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return newUser;
  }

  updateUsuario(id: string, updates: Partial<Usuario>): boolean {
    if (this.currentUser.rol !== 'Administrador') {
      throw new Error('Solo el Administrador puede editar usuarios o asignar roles.');
    }
    const idx = this.usuarios.findIndex(u => u.id_usuario === id);
    if (idx === -1) return false;
    const prev = { ...this.usuarios[idx] };
    this.usuarios[idx] = { ...this.usuarios[idx], ...updates };
    this.saveUsuarios();

    realtimeService.mutate('usuarios', 'update', this.usuarios[idx]);

    this.recordAudit({
      accion: 'EDICION',
      modulo: 'USUARIOS',
      id_registro: id,
      cod_linea: '-',
      estructura: '-',
      valores_anteriores: JSON.stringify(prev),
      valores_nuevos: JSON.stringify(this.usuarios[idx]),
      origen: 'Web',
      resultado: 'Exitoso'
    });
    return true;
  }

  setUsuarios(users: Usuario[]) {
    this.usuarios = users;
    this.saveUsuarios();
  }

  private saveUsuarios() {
    localStorage.setItem(STORAGE_KEYS.USUARIOS, JSON.stringify(this.usuarios));
  }

  // --- CONFIGURACIÓN DRIVE ---
  getConfigDrive(): ConfiguracionDrive {
    return this.config;
  }

  updateConfigDrive(updates: Partial<ConfiguracionDrive>) {
    this.config = { ...this.config, ...updates };
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(this.config));
    this.recordAudit({
      accion: 'EDICION',
      modulo: 'CONFIG_DRIVE',
      id_registro: 'CONFIG',
      cod_linea: '-',
      estructura: '-',
      valores_anteriores: 'N/A',
      valores_nuevos: JSON.stringify(this.config),
      origen: 'Web',
      resultado: 'Exitoso'
    });
  }

  // --- CONFLICTOS ---
  getConflictos(): ConflictoRegistro[] {
    return this.conflictos;
  }

  addConflicto(conf: Omit<ConflictoRegistro, 'id_conflicto' | 'fecha_deteccion' | 'resuelto'>) {
    const { fecha, hora } = getLimaDateTime();
    const item: ConflictoRegistro = {
      ...conf,
      id_conflicto: 'CONF-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
      fecha_deteccion: `${fecha} ${hora}`,
      resuelto: false
    };
    this.conflictos.unshift(item);
    localStorage.setItem(STORAGE_KEYS.CONFLICTOS, JSON.stringify(this.conflictos));
  }

  resolveConflicto(id: string, decision: 'Local' | 'Drive') {
    const idx = this.conflictos.findIndex(c => c.id_conflicto === id);
    if (idx >= 0) {
      this.conflictos[idx].resuelto = true;
      this.conflictos[idx].resolucion = decision;
      localStorage.setItem(STORAGE_KEYS.CONFLICTOS, JSON.stringify(this.conflictos));
      this.recordAudit({
        accion: 'SINCRONIZACION',
        modulo: 'CONFLICTOS',
        id_registro: id,
        cod_linea: '-',
        estructura: '-',
        valores_anteriores: `Discrepancia en ${this.conflictos[idx].campo}`,
        valores_nuevos: `Resuelto: Se conservó valor ${decision}`,
        origen: 'Web',
        resultado: 'Exitoso'
      });
    }
  }

  // --- EVIDENCIAS FOTOGRÁFICAS ---
  getEvidencias(codLinea?: string, posteN?: string): EvidenciaFotografica[] {
    let list = this.evidencias;
    if (codLinea) list = list.filter(e => e.cod_linea === codLinea);
    if (posteN) list = list.filter(e => e.poste_n === posteN);
    return list;
  }

  addEvidencia(ev: Omit<EvidenciaFotografica, 'id_evidencia' | 'fecha_registro'>): EvidenciaFotografica {
    const { fecha, hora } = getLimaDateTime();
    const newItem: EvidenciaFotografica = {
      ...ev,
      id_evidencia: 'EVI-' + Math.random().toString(36).substring(2, 9).toUpperCase(),
      fecha_registro: `${fecha} ${hora}`
    };
    this.evidencias.unshift(newItem);
    localStorage.setItem(STORAGE_KEYS.EVIDENCIAS, JSON.stringify(this.evidencias.slice(0, 500)));
    return newItem;
  }
}

export const storageService = new StorageService();
