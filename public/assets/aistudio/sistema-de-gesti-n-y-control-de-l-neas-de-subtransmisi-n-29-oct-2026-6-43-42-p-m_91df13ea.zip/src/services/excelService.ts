import * as XLSX from 'xlsx';
import {
  LineaSubtransmision,
  Estructura,
  EfectoCorona,
  Deficiencia,
  Poda,
  Mantenimiento,
  DMSItem,
  LevantamientoDMS,
  InspeccionCierreDMS,
  AuditoriaRegistro,
  Usuario
} from '../types';

export class ExcelService {
  /**
   * Helper to download workbook
   */
  private static downloadWorkbook(wb: XLSX.WorkBook, filename: string) {
    XLSX.writeFile(wb, filename);
  }

  // 1. Export Líneas
  static exportLineas(lineas: LineaSubtransmision[], filename = 'Registro_Lineas.xlsx') {
    const data = lineas.map(l => ({
      ID_LINEA: l.id_linea,
      COD_LINEA: String(l.cod_linea),
      NOMBRE: l.nombre,
      TIPO_SISTEMA: l.tipo_sistema,
      TENSION_NOM: String(l.tension_nom),
      NODO_SALIDA: l.nodo_salida,
      NODO_LLEGADA: l.nodo_llegada,
      CELDA_SALIDA: l.celda_salida,
      CELDA_LLEGADA: l.celda_llegada,
      ESTADO: l.estado,
      ULTIMA_SINCRONIZACION: l.ultima_sincronizacion
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'LINEAS');
    this.downloadWorkbook(wb, filename);
  }

  // 2. Export Estructuras
  static exportEstructuras(estructuras: Estructura[], filename = 'Registro_Estructuras.xlsx') {
    const data = estructuras.map(e => ({
      ID_POSTE: e.id_poste,
      COD_LINEA: String(e.cod_linea),
      POSTE_N: String(e.poste_n),
      TIPO_ARMADO: e.tipo_armado,
      POSTE_CANTIDAD: e.poste_cantidad,
      POSTE_MATERIAL: e.poste_material,
      CRUCETA_MATERIAL: e.cruceta_material,
      MENSULA_MATERIAL: e.mensula_material,
      RIOSTRA_O_AMARRE_MATERIAL: e.riostra_o_amarre_material,
      AISLADOR_MATERIAL: e.aislador_material,
      AISLADOR_CANT: e.aislador_cant,
      AISLADOR_TIPO: e.aislador_tipo,
      CONDUCTOR_MATERIAL: e.conductor_material,
      CONDUCTOR_CALIBRE: e.conductor_calibre,
      CONDUCTOR_N_FASES: e.conductor_n_fases,
      ESTADO: e.estado,
      OBSERVACIONES: e.observaciones || ''
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'ESTRUCTURAS');
    this.downloadWorkbook(wb, filename);
  }

  // 3. Export Efecto Corona
  static exportCorona(corona: EfectoCorona[], filename = 'Registro_Efecto_Corona.xlsx') {
    const data = corona.map(c => ({
      ID_CORONA: c.id_corona,
      COD_LINEA: String(c.cod_linea),
      POSTE_N: String(c.poste_n),
      TIPO_ARMADO: c.tipo_armado,
      TIPO_AISLADOR: c.tipo_aislador,
      NIVEL_TENSION_KV: c.nivel_tension_kv,
      TEMP_C: c.temp_c,
      HUMEDAD_PCT: c.humedad_pct,
      FASE_R_GANANCIA: c.fase_r_ganancia,
      FASE_R_CONTEO_FOTON_MINUTO: c.fase_r_conteo,
      FASE_S_GANANCIA: c.fase_s_ganancia,
      FASE_S_CONTEO_FOTON_MINUTO: c.fase_s_conteo,
      FASE_T_GANANCIA: c.fase_t_ganancia,
      FASE_T_CONTEO_FOTON_MINUTO: c.fase_t_conteo,
      FECHA: c.fecha,
      HORA: c.hora,
      COMENTARIOS: c.comentarios,
      SITUACIONES: (c.situaciones || []).join('; '),
      EVIDENCIA_URL: c.evidencia_url || '',
      INSPECTOR: c.inspector || ''
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'EFECTO_CORONA');
    this.downloadWorkbook(wb, filename);
  }

  // 4. Export Deficiencias
  static exportDeficiencias(deficiencias: Deficiencia[], filename = 'Registro_Deficiencias.xlsx') {
    const data = deficiencias.map(d => ({
      ID_DEFICIENCIA: d.id_deficiencia,
      COD_LINEA: String(d.cod_linea),
      POSTE_N: String(d.poste_n),
      FECHA_INSPECCION: d.fecha_inspeccion,
      TIPO_DEFICIENCIA: d.tipo_deficiencia,
      DESCRIPCION: d.descripcion,
      PRIORIDAD: d.prioridad,
      EVIDENCIA_FOTOGRAFICA: d.evidencia_fotografica,
      OBSERVACIONES: d.observaciones,
      USUARIO_RESPONSABLE: d.usuario_responsable,
      ESTADO: d.estado,
      FECHA_CIERRE: d.fecha_cierre || ''
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'DEFICIENCIAS');
    this.downloadWorkbook(wb, filename);
  }

  // 5. Export Podas
  static exportPodas(podas: Poda[], filename = 'Registro_Podas.xlsx') {
    const data = podas.map(p => ({
      ID_PODA: p.id_poda,
      COD_LINEA: String(p.cod_linea),
      POSTE_N: String(p.poste_n),
      TIPO_ARMADO: p.tipo_armado,
      TIPO_AISLADOR: p.tipo_aislador,
      NIVEL_TENSION_KV: p.nivel_tension_kv,
      FECHA_EJECUCION: p.fecha_ejecucion,
      UBICACION_REFERENCIA: p.ubicacion_referencia,
      PUNTO_INICIAL: p.punto_inicial,
      PUNTO_FINAL: p.punto_final,
      ALGARROBO: p.algarrobo,
      PALMERA: p.palmera,
      ORNAMENTAL: p.ornamental,
      TAMARINDO: p.tamarindo,
      PONCEANA: p.ponceana,
      OTROS: p.otros,
      TOTAL_ARBOLES: p.total_arboles,
      OBSERVACIONES: p.observaciones,
      CONTRATISTA_RESPONSABLE: p.contratista_responsable,
      ESTADO: p.estado
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'PODAS');
    this.downloadWorkbook(wb, filename);
  }

  // 6. Export Mantenimiento
  static exportMantenimiento(mantenimientos: Mantenimiento[], filename = 'Registro_Mantenimiento.xlsx') {
    const data = mantenimientos.map(m => ({
      ID_MANTENIMIENTO: m.id_mantenimiento,
      COD_LINEA: String(m.cod_linea),
      POSTE_N: String(m.poste_n),
      FECHA_EJECUCION: m.fecha_ejecucion,
      TIPO_MANTENIMIENTO: m.tipo_mantenimiento,
      ACTIVIDAD_REALIZADA: m.actividad_realizada,
      ORDEN_MANTENIMIENTO: m.orden_mantenimiento,
      OBSERVACIONES: m.observaciones,
      CONTRATISTA_RESPONSABLE: m.contratista_responsable,
      ESTADO: m.estado,
      ALTERA_ESTRUCTURAS: m.altera_estructuras ? 'SÍ' : 'NO',
      DETALLE_REORDENAMIENTO: m.detalle_reordenamiento || ''
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'MANTENIMIENTO');
    this.downloadWorkbook(wb, filename);
  }

  // 7. Export DMS Completo
  static exportDMS(
    dms: DMSItem[],
    levantamientos: LevantamientoDMS[],
    inspecciones: InspeccionCierreDMS[],
    filename = 'Registro_DMS.xlsx'
  ) {
    const wb = XLSX.utils.book_new();

    // Hoja 1: Registro_DMS
    const dmsData = dms.map(d => ({
      ID_DMS: d.id_dms,
      COD_LINEA: String(d.cod_linea),
      POSTE_N: String(d.poste_n),
      CODIGO_DMS: d.codigo_dms,
      DESCRIPCION: d.descripcion,
      FECHA_IDENTIFICACION: d.fecha_identificacion,
      PRIORIDAD: d.prioridad,
      FUENTE: d.fuente,
      ORDEN_SERVICIO: d.orden_servicio,
      ESTADO: d.estado,
      OBSERVACIONES: d.observaciones
    }));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(dmsData), 'Registro_DMS');

    // Hoja 2: Levantamiento_DMS
    const levData = levantamientos.map(l => ({
      ID_LEVANTAMIENTO: l.id_levantamiento,
      ID_DMS: l.id_dms,
      COD_LINEA: String(l.cod_linea),
      POSTE_N: String(l.poste_n),
      FECHA_EJECUCION: l.fecha_ejecucion,
      DESCRIPCION_TRABAJO: l.descripcion_trabajo,
      ORDEN_SERVICIO: l.orden_servicio,
      CONTRATISTA_RESPONSABLE: l.contratista_responsable,
      ESTADO: l.estado,
      OBSERVACIONES: l.observaciones
    }));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(levData), 'Levantamiento_DMS');

    // Hoja 3: Inspecciones_Cierre_DMS
    const inspData = inspecciones.map(i => ({
      ID_INSPECCION_CIERRE: i.id_inspeccion_cierre,
      ID_DMS: i.id_dms,
      ID_LEVANTAMIENTO: i.id_levantamiento,
      COD_LINEA: String(i.cod_linea),
      POSTE_N: String(i.poste_n),
      FECHA_INSPECCION: i.fecha_inspeccion,
      INSPECTOR: i.inspector,
      RESULTADO: i.resultado,
      ESTADO_FINAL: i.estado_final,
      OBSERVACIONES: i.observaciones
    }));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(inspData), 'Inspecciones_Cierre_DMS');

    this.downloadWorkbook(wb, filename);
  }

  // 8. Export Auditoría
  static exportAuditoria(auditoria: AuditoriaRegistro[], filename = 'Historial_Modificaciones.xlsx') {
    const data = auditoria.map(a => ({
      ID_AUDITORIA: a.id_auditoria,
      USUARIO: a.usuario,
      ROL: a.rol,
      FECHA: a.fecha,
      HORA: a.hora,
      ACCION: a.accion,
      MODULO: a.modulo,
      ID_REGISTRO: a.id_registro,
      COD_LINEA: a.cod_linea,
      ESTRUCTURA: a.estructura,
      VALORES_ANTERIORES: a.valores_anteriores,
      VALORES_NUEVOS: a.valores_nuevos,
      ORIGEN: a.origen,
      RESULTADO: a.resultado,
      SYNC_ID: a.sync_id
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Historial_Modificaciones');
    this.downloadWorkbook(wb, filename);
  }

  // 9. Export Usuarios (matching exact columns of USUARIOS.XLSX)
  static exportUsuarios(usuarios: Usuario[], filename = 'USUARIOS.xlsx') {
    const data = usuarios.map(u => ({
      ID: u.id_usuario,
      NOMBRES: u.nombres,
      APELLIDOS: u.apellidos,
      DOCUMENTO: u.dni,
      EMAIL: u.email,
      TELEFONO: u.telefono,
      USERNAME: u.username,
      ROL: u.rol,
      ESTADO: u.estado,
      SUPERVISOR_RESPONSABLE: u.supervisor_responsable || '',
      LINEAS_ASIGNADAS: u.lineas_asignadas.includes('*') ? '*' : u.lineas_asignadas.join(', '),
      FECHA_CREACION: u.fecha_creacion,
      ULTIMA_ACTUALIZACION: u.ultima_actualizacion || new Date().toISOString().replace('T', ' ').substring(0, 19)
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'USUARIOS');
    this.downloadWorkbook(wb, filename);
  }

  /**
   * Reads an uploaded Excel file and returns sheets data
   */
  static async readExcelFile(file: File): Promise<{ sheetNames: string[]; data: Record<string, any[]> }> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const buffer = e.target?.result;
          const wb = XLSX.read(buffer, { type: 'binary' });
          const result: Record<string, any[]> = {};
          wb.SheetNames.forEach(sheetName => {
            const sheet = wb.Sheets[sheetName];
            result[sheetName] = XLSX.utils.sheet_to_json(sheet, { defval: '' });
          });
          resolve({ sheetNames: wb.SheetNames, data: result });
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = reject;
      reader.readAsBinaryString(file);
    });
  }
}
